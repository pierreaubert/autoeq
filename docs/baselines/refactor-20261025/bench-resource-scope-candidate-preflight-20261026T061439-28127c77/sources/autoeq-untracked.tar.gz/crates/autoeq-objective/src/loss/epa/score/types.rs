use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

/// Program-material bias for temporal masking.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize, JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum TemporalMaskingProfile {
    /// Percussive material: modal ringing is least masked and should be cut
    /// more decisively.
    Transient,
    /// General music / film content.
    #[default]
    Mixed,
    /// Sustained material: late modal decay is partly masked by ongoing tone.
    Sustained,
}

/// True impulse-response temporal masking metrics for FIR / phase correction.
#[derive(Debug, Clone, Serialize, Deserialize, JsonSchema)]
pub struct TemporalIrMaskingMetrics {
    /// Main impulse sample index used as the transient reference.
    pub main_index: usize,
    /// Main impulse time in milliseconds from the start of the FIR.
    pub main_time_ms: f64,
    /// Peak pre-ringing level before the main impulse, dB relative to main.
    pub pre_ringing_peak_db: f64,
    /// Peak post-ringing level after the main impulse, dB relative to main.
    pub post_ringing_peak_db: f64,
    /// Pre-masked audible pre-ringing energy, dB relative to main peak energy.
    pub pre_ringing_audible_db: f64,
    /// Post-masked audible post-ringing energy, dB relative to main peak energy.
    pub post_ringing_audible_db: f64,
    /// Physical pre-main energy (unmasked), dB relative to main peak energy.
    ///
    /// The raw precursor energy before any masking model applies: peak
    /// (`pre_ringing_peak_db`), physical energy (this field), and the
    /// masking-model prediction (`pre_ringing_audible_db`) answer three
    /// different questions and must never be conflated.
    pub pre_energy_ratio_db: f64,
    /// Scalar penalty using the configured material profile and IR weights.
    pub penalty: f64,
    /// Analyzed impulse length in taps.
    pub taps: usize,
    /// Sample rate the impulse was analyzed at, in Hz.
    pub sample_rate_hz: f64,
    /// Masking-model programme profile assumed (`transient`/`mixed`/`sustained`).
    pub masking_profile: String,
    /// Pre-masking window retained from the analysis assumptions, in ms.
    pub pre_mask_ms: f64,
    /// Post-masking window retained from the analysis assumptions, in ms.
    pub post_mask_ms: f64,
    /// Audibility threshold retained from the analysis assumptions, in dB.
    pub audibility_threshold_db: f64,
}

/// Modal descriptor retained for experimental temporal diagnostics.
///
/// It does not steer the active EPA optimizer, which uses spectral flatness
/// only.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TemporalMaskingMode {
    pub frequency: f64,
    pub q: f64,
    pub prominence_db: f64,
    pub temporal_severity_db: f64,
}

/// EPA dimensions computed from a frequency response.
#[derive(Debug, Clone, Serialize, Deserialize, JsonSchema)]
pub struct EpaScore {
    /// Evaluation: general quality (higher = better, 0-10 scale)
    pub evaluation: f64,
    /// Potency: perceived energy/strength (0-10 scale)
    pub potency: f64,
    /// Diagnostic Activity descriptor (0-10 scale).
    pub activity: f64,
    /// Diagnostic weighted composite; not a validated listener-preference prediction.
    pub preference: f64,
    /// Individual transfer-response shape diagnostics.
    pub sharpness_acum: f64,
    pub roughness: f64,
    pub total_loudness_sone: f64,
    pub loudness_balance: f64,
}

/// BS.1770-style channel role for multichannel EPA aggregation.
///
/// This is used for frequency-response diagnostics, not for time-domain LUFS
/// metering. It follows the BS.1770 convention of unit weight for front/main
/// programme channels, +1.5 dB energy weight for surround channels, and no
/// contribution from LFE/subwoofer channels.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EpaChannelRole {
    Main,
    Surround,
    Lfe,
}

/// Infer a coarse EPA channel role from a room-EQ channel name.
pub fn infer_epa_channel_role(channel_name: &str) -> EpaChannelRole {
    let name = channel_name.to_ascii_lowercase();
    let compact: String = name
        .chars()
        .filter(|ch| ch.is_ascii_alphanumeric())
        .collect();

    if compact.contains("lfe")
        || compact.contains("subwoofer")
        || compact == "sub"
        || compact.starts_with("sub")
    {
        EpaChannelRole::Lfe
    } else if compact.contains("surround")
        || compact.contains("rear")
        || compact.contains("side")
        || compact == "ls"
        || compact == "rs"
        || compact == "sl"
        || compact == "sr"
    {
        EpaChannelRole::Surround
    } else {
        EpaChannelRole::Main
    }
}
