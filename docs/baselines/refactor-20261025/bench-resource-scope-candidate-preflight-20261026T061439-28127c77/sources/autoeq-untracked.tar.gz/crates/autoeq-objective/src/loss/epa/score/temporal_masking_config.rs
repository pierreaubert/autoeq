use super::default::default_ir_audibility_threshold_db;
use super::default::default_ir_temporal_masking_enabled;
use super::default::default_ir_temporal_masking_weight;
use super::default::default_post_mask_ms;
use super::default::default_post_ringing_weight;
use super::default::default_pre_mask_ms;
use super::default::default_pre_ringing_weight;
use super::default::default_temporal_masking_enabled;
use super::default::default_temporal_masking_weight;
use super::types::TemporalMaskingProfile;
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

/// Experimental EPA temporal-diagnostic configuration.
///
/// These controls are retained for report compatibility and offline analysis;
/// they do not steer the active spectral-flatness-only EPA optimizer.
#[derive(Debug, Clone, Serialize, Deserialize, JsonSchema)]
pub struct TemporalMaskingConfig {
    /// Enable the legacy modal temporal diagnostic when modal data is available.
    #[serde(default = "default_temporal_masking_enabled")]
    pub enabled: bool,
    /// Legacy diagnostic weight; it does not steer EPA optimizer fitness.
    #[serde(default = "default_temporal_masking_weight")]
    pub weight: f64,
    /// Diagnostic programme-profile label for modal-ringing reporting.
    #[serde(default)]
    pub profile: TemporalMaskingProfile,
    /// Enable true FIR impulse-response pre/post masking analysis when FIR
    /// coefficients are available.
    #[serde(default = "default_ir_temporal_masking_enabled")]
    pub ir_enabled: bool,
    /// Weight applied to the IR masking penalty metric.
    #[serde(default = "default_ir_temporal_masking_weight")]
    pub ir_weight: f64,
    /// Pre-masking window before the main impulse. Pre-ringing inside this
    /// window is partially masked; earlier energy is fully audible.
    #[serde(default = "default_pre_mask_ms")]
    pub pre_mask_ms: f64,
    /// Post-masking window after the main impulse. Ringing grows more audible
    /// as it decays beyond this window.
    #[serde(default = "default_post_mask_ms")]
    pub post_mask_ms: f64,
    /// Relative weight for audible pre-ringing. Usually higher than post
    /// because pre-echo before a transient is especially objectionable.
    #[serde(default = "default_pre_ringing_weight")]
    pub pre_ringing_weight: f64,
    /// Relative weight for audible post-ringing.
    #[serde(default = "default_post_ringing_weight")]
    pub post_ringing_weight: f64,
    /// Audibility floor for weighted pre/post ringing energy, in dB relative
    /// to the main impulse peak.
    #[serde(default = "default_ir_audibility_threshold_db")]
    pub ir_audibility_threshold_db: f64,
}

impl Default for TemporalMaskingConfig {
    fn default() -> Self {
        Self {
            enabled: default_temporal_masking_enabled(),
            weight: default_temporal_masking_weight(),
            profile: TemporalMaskingProfile::Mixed,
            ir_enabled: default_ir_temporal_masking_enabled(),
            ir_weight: default_ir_temporal_masking_weight(),
            pre_mask_ms: default_pre_mask_ms(),
            post_mask_ms: default_post_mask_ms(),
            pre_ringing_weight: default_pre_ringing_weight(),
            post_ringing_weight: default_post_ringing_weight(),
            ir_audibility_threshold_db: default_ir_audibility_threshold_db(),
        }
    }
}
