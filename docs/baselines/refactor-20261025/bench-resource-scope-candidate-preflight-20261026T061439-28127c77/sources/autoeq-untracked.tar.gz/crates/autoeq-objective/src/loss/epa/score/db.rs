pub(super) fn db_from_ratio(ratio: f64) -> f64 {
    if ratio <= 1e-24 {
        -240.0
    } else {
        20.0 * ratio.log10()
    }
}

pub(super) fn db_from_energy_ratio(ratio: f64) -> f64 {
    if ratio <= 1e-24 {
        -240.0
    } else {
        10.0 * ratio.log10()
    }
}
