use super::super::constraints::{
    viol_ceiling_from_spl, viol_min_gain_from_xs, viol_spacing_from_xs,
};
use super::super::loss::LossType;
use super::super::x2peq::x2spl_into;
use super::clamp::{clamp_cuts_to_envelope, clamp_envelopes_into, clamp_gains_to_envelope};
use super::loss::ObjectiveContext;
use super::objective_data::ObjectiveData;
use super::smoothness_penalty_config::SmoothnessPenaltyConfig;
use super::types::MultiObjectiveData;
use crate::PeqModel;
use crate::param_utils::PeqLayout;
use ndarray::Array1;
use std::cell::RefCell;
use std::sync::Arc;

#[cfg(test)]
thread_local! {
    static RESPONSE_COMPUTATIONS: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
}

#[inline]
fn record_response_computation() {
    #[cfg(test)]
    RESPONSE_COMPUTATIONS.with(|count| count.set(count.get() + 1));
}

struct EvaluationScratch {
    parameters: Vec<f64>,
    response_parameters: Vec<f64>,
    response_freqs: Option<Arc<Array1<f64>>>,
    response_srate: f64,
    response_peq_model: Option<PeqModel>,
    peq: crate::iir::Peq,
    response: Array1<f64>,
    filter_response: Array1<f64>,
    error: Array1<f64>,
    smoothed_error: Array1<f64>,
    multi_losses: Vec<f64>,
    multi_losses_sorted: Vec<f64>,
}

impl EvaluationScratch {
    fn new() -> Self {
        Self {
            parameters: Vec::new(),
            response_parameters: Vec::new(),
            response_freqs: None,
            response_srate: f64::NAN,
            response_peq_model: None,
            peq: crate::iir::Peq::new(),
            response: Array1::zeros(0),
            filter_response: Array1::zeros(0),
            error: Array1::zeros(0),
            smoothed_error: Array1::zeros(0),
            multi_losses: Vec::new(),
            multi_losses_sorted: Vec::new(),
        }
    }

    fn ensure_frequency_len(&mut self, len: usize) {
        if self.response.len() != len {
            self.response = Array1::zeros(len);
            self.filter_response = Array1::zeros(len);
            self.error = Array1::zeros(len);
            self.smoothed_error = Array1::zeros(len);
        }
    }
}

thread_local! {
    static EVALUATION_SCRATCH: RefCell<EvaluationScratch> = RefCell::new(EvaluationScratch::new());
}

/// Compute multi-objective fitness across multiple measurement curves.
///
/// Each objective shares the same filter parameters `x` but evaluates against
/// a different measurement curve. The per-curve losses are combined according
/// to the configured strategy.
fn variance_penalized_loss(
    weighted_losses: impl IntoIterator<Item = (f64, f64)>,
    variance_lambda: f64,
) -> f64 {
    let mut total_weight = 0.0;
    let mut mean = 0.0;
    let mut sum_squared_deviation = 0.0;
    for (loss, weight) in weighted_losses {
        if weight <= 0.0 {
            continue;
        }
        total_weight += weight;
        let delta = loss - mean;
        mean += (weight / total_weight) * delta;
        sum_squared_deviation += weight * delta * (loss - mean);
    }
    if total_weight <= 0.0 {
        return f64::INFINITY;
    }
    let variance = sum_squared_deviation / total_weight;
    mean + variance_lambda * variance
}

/// Equal-mass empirical upper-tail CVaR over per-sample losses.
///
/// Sorts `losses` worst-first in place, then averages the worst `alpha`
/// fraction of the empirical mass, splitting one sample fractionally when
/// `alpha * N` is not an integer (e.g. losses `[10, 0, 0]` with
/// `alpha = 0.5` cover mass `1.5`, giving `10 / 1.5 ≈ 6.6667`). This matches
/// the fractional-weight definition used by the continuous-area CVaR
/// scalarisation. Ties need no special handling: any fractional split of
/// equal values yields the same mean. Endpoints fall out naturally:
/// `alpha >= 1` is the mean, and `alpha -> 0` approaches the max.
/// An empty input yields `+inf`; a `NaN` sample inside the tail surfaces as
/// `+inf` worst-case instead of propagating `NaN` through the optimiser.
fn fractional_tail_cvar_into(losses: &mut [f64], alpha: f64) -> f64 {
    if losses.is_empty() {
        return f64::INFINITY;
    }
    // Worst losses first. `total_cmp` pins NaN at the head (worst) so a
    // corrupted sample poisons the tail instead of hiding inside it.
    losses.sort_by(|a, b| b.total_cmp(a));
    if alpha.is_nan() || alpha <= 0.0 {
        return losses[0];
    }
    if alpha >= 1.0 {
        return losses.iter().sum::<f64>() / losses.len() as f64;
    }
    let mass = alpha * losses.len() as f64;
    let mut acc = 0.0;
    let mut taken = 0.0;
    for &loss in losses.iter() {
        if taken >= mass {
            break;
        }
        let take = (mass - taken).min(1.0);
        acc += take * if loss.is_nan() { f64::INFINITY } else { loss };
        taken += take;
    }
    acc / mass
}

/// Scalarise already-evaluated per-objective losses without re-evaluating.
///
/// Centralises every [`MultiMeasurementStrategy`] reduction so the fitness
/// and Pareto paths share one definition (in particular the fractional-tail
/// bootstrap CVaR).
fn scalarise_losses(losses: &[f64], mo: &MultiObjectiveData) -> f64 {
    use crate::roomeq::MultiMeasurementStrategy;

    match mo.strategy {
        MultiMeasurementStrategy::Average => losses.iter().sum::<f64>() / losses.len() as f64,
        MultiMeasurementStrategy::WeightedSum => losses
            .iter()
            .zip(&mo.weights)
            .map(|(loss, weight)| loss * weight)
            .sum(),
        MultiMeasurementStrategy::Minimax => losses
            .iter()
            .fold(f64::NEG_INFINITY, |a, &b| f64::max(a, b)),
        MultiMeasurementStrategy::VariancePenalized => variance_penalized_loss(
            losses
                .iter()
                .zip(&mo.weights)
                .map(|(loss, weight)| (*loss, *weight)),
            mo.variance_lambda,
        ),
        MultiMeasurementStrategy::SpatialRobustness => {
            // Engine adapters map SpatialRobustness to direct per-seat
            // VariancePenalized risk before constructing this optimizer payload.
            unreachable!("unadapted SpatialRobustness strategy reached optimizer")
        }
        MultiMeasurementStrategy::MinimaxUncertainty => {
            // The bootstrap-resampled objectives have already been materialised
            // into `mo.objectives` at setup time. Either take the max (pure
            // worst-case) or the fractional-tail mean (CVaR).
            match mo.uncertainty_cvar_alpha {
                None => losses
                    .iter()
                    .fold(f64::NEG_INFINITY, |a, &b| f64::max(a, b)),
                Some(alpha) => {
                    let alpha = alpha.clamp(f64::MIN_POSITIVE, 1.0);
                    // Dedicated sort buffer: the caller
                    // (`compute_multi_objective_fitness`) already holds the
                    // shared `multi_losses` scratch as `losses`, so reusing
                    // it here would take an empty stand-in, allocate on
                    // every call, and lose the retained capacity on restore.
                    let mut sorted = EVALUATION_SCRATCH
                        .with(|slot| std::mem::take(&mut slot.borrow_mut().multi_losses_sorted));
                    sorted.clear();
                    sorted.extend_from_slice(losses);
                    let result = fractional_tail_cvar_into(&mut sorted, alpha);
                    EVALUATION_SCRATCH.with(|slot| {
                        slot.borrow_mut().multi_losses_sorted = sorted;
                    });
                    result
                }
            }
        }
    }
}

fn compute_multi_objective_fitness(x: &[f64], mo: &MultiObjectiveData) -> f64 {
    let mut losses =
        EVALUATION_SCRATCH.with(|slot| std::mem::take(&mut slot.borrow_mut().multi_losses));
    losses.clear();
    losses.extend(
        mo.objectives
            .iter()
            .map(|objective| compute_base_fitness_single(x, objective)),
    );
    let result = scalarise_losses(&losses, mo);
    EVALUATION_SCRATCH.with(|slot| {
        slot.borrow_mut().multi_losses = losses;
    });
    result
}

/// Base objective for a complete realized correction on each objective's grid.
/// Responses are dB magnitudes in objective order, not corrected measurements.
/// Uses the same per-seat losses and scalarisation as the PEQ optimizer, but
/// does not apply PEQ parameter constraints: the caller owns delivered-chain
/// gain, support, temporal and resource validation. `None` means the objective
/// needs a richer physical transfer than this scalar response interface.
pub fn compute_response_fitness(responses: &[Array1<f64>], data: &ObjectiveData) -> Option<f64> {
    let evaluate = |response: &Array1<f64>, objective_data: &ObjectiveData| {
        if matches!(
            objective_data.loss_type,
            LossType::SpeakerFlat | LossType::HeadphoneFlat | LossType::SpeakerFlatAsymmetric
        ) {
            if response.len() != objective_data.freqs.len()
                || response.len() != objective_data.deviation.len()
                || response.iter().any(|value| !value.is_finite())
            {
                return Some(f64::INFINITY);
            }
            let mut error = response - &*objective_data.deviation;
            return Some(evaluate_prepared_flat_response(
                response,
                &mut error,
                objective_data,
            ));
        }
        let objective = objective_data
            .objective
            .clone()
            .unwrap_or_else(|| objective_data.build_objective());
        let ctx = ObjectiveContext {
            freqs: &objective_data.freqs,
            target: &objective_data.target,
            deviation: &objective_data.deviation,
            srate: objective_data.srate,
            peq_model: objective_data.peq_model,
            min_freq: objective_data.min_freq,
            max_freq: objective_data.max_freq,
            smooth: objective_data.smooth,
            smooth_n: objective_data.smooth_n,
            audibility_deadband: objective_data.audibility_deadband.as_ref(),
            smoothness_penalty: objective_data.smoothness_penalty.as_ref(),
        };
        objective.compute_response(response, &ctx)
    };
    if let Some(multi) = &data.multi_objective {
        if responses.len() != multi.objectives.len() || responses.is_empty() {
            return Some(f64::INFINITY);
        }
        let losses: Option<Vec<f64>> = responses
            .iter()
            .zip(&multi.objectives)
            .map(|(response, objective)| evaluate(response, objective))
            .collect();
        losses.map(|losses| {
            if losses.iter().any(|loss| !loss.is_finite()) {
                f64::INFINITY
            } else {
                scalarise_losses(&losses, multi)
            }
        })
    } else if responses.len() == 1 {
        evaluate(&responses[0], data)
    } else {
        Some(f64::INFINITY)
    }
}

/// Compute the objective vector used by Pareto optimizers.
///
/// For multi-measurement data this returns the per-measurement losses before
/// scalarisation, with any shared AutoEQ penalty added to each component. For
/// ordinary scalar objectives it returns a one-element vector containing the
/// penalised scalar loss.
pub fn compute_pareto_objectives(x: &[f64], data: &ObjectiveData) -> Vec<f64> {
    try_compute_pareto_objectives(x, data).unwrap_or_else(|_| {
        let objective_count = data
            .multi_objective
            .as_ref()
            .map_or(1, |multi| multi.objectives.len().max(1));
        vec![f64::INFINITY; objective_count]
    })
}

/// Why an explicitly tracked score could not start.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ValidationScoreRefusal {
    /// The invocation's cancellation or deadline gate refused the score.
    TerminalStop,
    /// A non-terminal search-budget or stage gate refused the score.
    NonTerminal,
}

/// Compute Pareto objectives while preserving the validation gate's typed stop refusal.
pub fn try_compute_pareto_objectives(
    x: &[f64],
    data: &ObjectiveData,
) -> Result<Vec<f64>, ValidationScoreRefusal> {
    let _evaluation_guard = begin_controlled_evaluation(data).map_err(|()| {
        if data.terminal_stop_requested() {
            ValidationScoreRefusal::TerminalStop
        } else {
            ValidationScoreRefusal::NonTerminal
        }
    })?;
    Ok(compute_pareto_objectives_uncontrolled(x, data))
}

fn compute_pareto_objectives_uncontrolled(x: &[f64], data: &ObjectiveData) -> Vec<f64> {
    let Ok(projected) = super::resolution_guard::guarded_parameters(x, data, |_| {}) else {
        return vec![
            f64::INFINITY;
            data.multi_objective
                .as_ref()
                .map_or(1, |multi| multi.objectives.len())
        ];
    };
    let x = projected.as_ref();
    if let Some(ref mo) = data.multi_objective {
        // Evaluate each per-measurement loss once; the scalarisation and the
        // shared penalty are pure reductions over those values, so no
        // objective is ever evaluated twice for the same `x`.
        let losses: Vec<f64> = mo
            .objectives
            .iter()
            .map(|obj| compute_base_fitness_single(x, obj))
            .collect();
        let base_scalar = scalarise_losses(&losses, mo);
        let mut penalized_scalar = base_scalar;
        for term in penalty_terms(x, data) {
            penalized_scalar += term;
        }
        let shared_penalty = (penalized_scalar - base_scalar).max(0.0);
        return losses
            .into_iter()
            .map(|loss| loss + shared_penalty)
            .collect();
    }

    vec![compute_fitness_penalties_uncontrolled(x, data)]
}

/// Compute second-difference L1 (or Lp) penalty on cascaded magnitude in
/// log-frequency. Returns 0.0 when disabled or under-sampled.
pub fn compute_smoothness_penalty(
    y: &Array1<f64>,
    freqs: &Array1<f64>,
    min_freq: f64,
    max_freq: f64,
    cfg: &SmoothnessPenaltyConfig,
) -> f64 {
    if cfg.tv2_weight <= 0.0 || y.len() < 3 || freqs.len() != y.len() {
        return 0.0;
    }

    let mut acc = 0.0_f64;
    let mut active_terms = 0usize;
    for i in 1..(y.len() - 1) {
        let f_c = freqs[i];
        if f_c < min_freq
            || f_c > max_freq
            || f_c <= 0.0
            || freqs[i - 1] <= 0.0
            || freqs[i + 1] <= 0.0
        {
            continue;
        }

        let lf_p = freqs[i + 1].log10();
        let lf_c = f_c.log10();
        let lf_m = freqs[i - 1].log10();
        let dx_fwd = lf_p - lf_c;
        let dx_bwd = lf_c - lf_m;
        if dx_fwd <= 0.0 || dx_bwd <= 0.0 {
            continue;
        }

        let slope_fwd = (y[i + 1] - y[i]) / dx_fwd;
        let slope_bwd = (y[i] - y[i - 1]) / dx_bwd;
        let curvature = (slope_fwd - slope_bwd) / (0.5 * (dx_fwd + dx_bwd));
        let w = match cfg.schroeder_hz {
            Some(fs) if f_c < fs => cfg.modal_weight_scale,
            _ => 1.0,
        };
        let term = if (cfg.exponent - 1.0).abs() < 1e-9 {
            curvature.abs()
        } else if (cfg.exponent - 2.0).abs() < 1e-9 {
            curvature * curvature
        } else {
            curvature.abs().powf(cfg.exponent)
        };
        acc += w * term;
        active_terms += 1;
    }

    if active_terms == 0 {
        0.0
    } else {
        cfg.tv2_weight * acc / active_terms as f64
    }
}

/// Compute the base fitness for a single ObjectiveData (no multi-objective delegation).
/// This is the inner implementation that does not check `multi_objective`.
fn compute_base_fitness_single(x: &[f64], data: &ObjectiveData) -> f64 {
    let Ok(projected) = super::resolution_guard::guarded_parameters(x, data, |_| {}) else {
        return f64::INFINITY;
    };
    let x = projected.as_ref();
    if matches!(
        data.loss_type,
        LossType::SpeakerFlat | LossType::HeadphoneFlat | LossType::SpeakerFlatAsymmetric
    ) {
        return compute_prepared_flat_fitness(x, data);
    }

    let clamped_boost;
    let clamped_cut;
    let x = {
        let skip = matches!(
            data.loss_type,
            LossType::DriversFlat | LossType::MultiSubFlat
        );
        let x = if !skip && let Some(ref envelope) = data.max_boost_envelope {
            clamped_boost = clamp_gains_to_envelope(x, envelope, data.peq_model);
            &clamped_boost
        } else {
            x
        };
        if !skip && let Some(ref envelope) = data.min_cut_envelope {
            clamped_cut = clamp_cuts_to_envelope(x, envelope, data.peq_model);
            &clamped_cut
        } else {
            x
        }
    };

    let objective = data
        .objective
        .clone()
        .unwrap_or_else(|| data.build_objective());

    let ctx = ObjectiveContext {
        freqs: &data.freqs,
        target: &data.target,
        deviation: &data.deviation,
        srate: data.srate,
        peq_model: data.peq_model,
        min_freq: data.min_freq,
        max_freq: data.max_freq,
        smooth: data.smooth,
        smooth_n: data.smooth_n,
        audibility_deadband: data.audibility_deadband.as_ref(),
        smoothness_penalty: data.smoothness_penalty.as_ref(),
    };

    objective.compute(x, &ctx)
}

fn compute_prepared_flat_fitness(x: &[f64], data: &ObjectiveData) -> f64 {
    EVALUATION_SCRATCH.with(|slot| {
        let mut scratch = slot.borrow_mut();
        scratch.ensure_frequency_len(data.freqs.len());
        let EvaluationScratch {
            parameters,
            response_parameters,
            response_freqs,
            response_srate,
            response_peq_model,
            peq,
            response,
            filter_response,
            error,
            ..
        } = &mut *scratch;
        let x = clamp_envelopes_into(
            x,
            parameters,
            data.max_boost_envelope.as_deref(),
            data.min_cut_envelope.as_deref(),
            data.peq_model,
        );
        let response_is_cached = response_parameters.as_slice() == x
            && response_freqs
                .as_ref()
                .is_some_and(|freqs| Arc::ptr_eq(freqs, &data.freqs))
            && *response_srate == data.srate
            && *response_peq_model == Some(data.peq_model);
        if !response_is_cached {
            x2spl_into(
                &data.freqs,
                x,
                data.srate,
                data.peq_model,
                peq,
                response,
                filter_response,
            );
            record_response_computation();
            response_parameters.clear();
            response_parameters.extend_from_slice(x);
            *response_freqs = Some(data.freqs.clone());
            *response_srate = data.srate;
            *response_peq_model = Some(data.peq_model);
        }
        for ((value, &correction), &deviation) in error
            .iter_mut()
            .zip(response.iter())
            .zip(data.deviation.iter())
        {
            *value = correction - deviation;
        }
        evaluate_prepared_flat_response(response, error, data)
    })
}

fn evaluate_prepared_flat_response(
    response: &Array1<f64>,
    error: &mut Array1<f64>,
    data: &ObjectiveData,
) -> f64 {
    let prepared = data.prepared();
    // Score the unsuppressed signed error before deadband mutates the scratch.
    let epa_regression = prepared
        .epa_regression
        .as_ref()
        .map_or(0.0, |cost| cost.evaluate(error));
    prepared.apply_deadband(error.as_slice_mut().expect("contiguous error scratch"));
    let base = match data.loss_type {
        LossType::SpeakerFlat | LossType::HeadphoneFlat => prepared
            .flat
            .as_ref()
            .expect("prepared flat loss")
            .evaluate(error),
        LossType::SpeakerFlatAsymmetric => prepared
            .asymmetric
            .as_ref()
            .expect("prepared asymmetric loss")
            .evaluate(error),
        _ => unreachable!("prepared flat path only handles flat objectives"),
    };
    base + epa_regression
        + prepared
            .null_boost
            .as_ref()
            .map_or(0.0, |penalty| penalty.evaluate_null_boost(response))
        + prepared
            .smoothness
            .as_ref()
            .map(|penalty| {
                penalty.evaluate(response.as_slice().expect("contiguous response scratch"))
            })
            .unwrap_or(0.0)
}

/// Evaluate a PEQ ceiling constraint using the response left by the objective
/// on this worker, or the same reusable buffers on a cache miss.
pub fn compute_ceiling_violation_into(
    freqs: &Arc<Array1<f64>>,
    x: &[f64],
    srate: f64,
    peq_model: PeqModel,
    max_db: f64,
) -> f64 {
    EVALUATION_SCRATCH.with(|slot| {
        let mut scratch = slot.borrow_mut();
        scratch.ensure_frequency_len(freqs.len());
        let response_is_cached = scratch.response_parameters.as_slice() == x
            && scratch
                .response_freqs
                .as_ref()
                .is_some_and(|cached| Arc::ptr_eq(cached, freqs))
            && scratch.response_srate == srate
            && scratch.response_peq_model == Some(peq_model);
        if !response_is_cached {
            let EvaluationScratch {
                peq,
                response,
                filter_response,
                response_parameters,
                response_freqs,
                response_srate,
                response_peq_model,
                ..
            } = &mut *scratch;
            x2spl_into(freqs, x, srate, peq_model, peq, response, filter_response);
            record_response_computation();
            response_parameters.clear();
            response_parameters.extend_from_slice(x);
            *response_freqs = Some(freqs.clone());
            *response_srate = srate;
            *response_peq_model = Some(peq_model);
        }
        viol_ceiling_from_spl(&scratch.response, max_db, peq_model)
    })
}

/// Compute the base fitness value (without penalties) for given parameters
///
/// This is the unified fitness function used by both NLOPT and metaheuristics optimizers.
/// If `multi_objective` is set, delegates to multi-objective fitness computation.
pub fn compute_base_fitness(x: &[f64], data: &ObjectiveData) -> f64 {
    let Ok(projected) = super::resolution_guard::guarded_parameters(x, data, |_| {}) else {
        return f64::INFINITY;
    };
    let x = projected.as_ref();
    // If multi-objective data is present, delegate to multi-objective fitness
    if let Some(ref mo) = data.multi_objective {
        return compute_multi_objective_fitness(x, mo);
    }

    compute_base_fitness_single(x, data)
}

/// Compute objective function value including penalty terms for constraints
///
/// Non-mutating version used by optimizers that don't require `&mut` data
/// (e.g., metaheuristics). Avoids cloning ObjectiveData on every evaluation.
/// Constraint penalty terms for `x`, in application order.
///
/// Returns `[ceiling, spacing, min_gain, q_rail]`; each entry is `0.0` when its
/// penalty is disabled or inapplicable. Split out so the Pareto path can add
/// the shared penalty to precomputed per-objective losses without
/// re-evaluating any objective.
fn penalty_terms(x: &[f64], data: &ObjectiveData) -> [f64; 4] {
    // PEQ-specific penalties only apply when the parameter vector has PEQ layout
    // (freq/Q/gain triplets). DriversFlat and MultiSubFlat use a different layout
    // (gains/delays/crossovers) and these penalty functions would misinterpret the values.
    let is_peq_loss = !matches!(
        data.loss_type,
        LossType::DriversFlat | LossType::MultiSubFlat
    );

    let mut terms = [0.0; 4];
    if data.penalty_w_ceiling > 0.0 && is_peq_loss {
        let viol =
            compute_ceiling_violation_into(&data.freqs, x, data.srate, data.peq_model, data.max_db);
        terms[0] = data.penalty_w_ceiling * viol * viol;
    }

    if data.penalty_w_spacing > 0.0 && is_peq_loss {
        let viol = viol_spacing_from_xs(x, data.peq_model, data.min_spacing_oct);
        terms[1] = data.penalty_w_spacing * viol * viol;
    }

    if data.penalty_w_mingain > 0.0 && data.min_db > 0.0 && is_peq_loss {
        let viol = viol_min_gain_from_xs(x, data.peq_model, data.min_db);
        terms[2] = data.penalty_w_mingain * viol * viol;
    }

    if is_peq_loss && let Some((rail, weight)) = data.q_rail_penalty {
        if !rail.is_finite() || rail <= 0.0 || !weight.is_finite() || weight < 0.0 {
            terms[3] = f64::INFINITY;
        } else if weight > 0.0 {
            let count = data.peq_model.num_filters(x);
            for index in 0..count {
                let filter = data.peq_model.get_filter_params(x, index);
                if !matches!(
                    data.peq_model
                        .determine_filter_type(index, count, filter.filter_type),
                    crate::iir::BiquadFilterType::Peak | crate::iir::BiquadFilterType::PeakMatched
                ) {
                    continue;
                }
                let frequency = 10.0_f64.powf(filter.freq);
                if frequency < data.min_freq || frequency > data.max_freq {
                    continue;
                }
                terms[3] += weight * filter.gain.abs() * (filter.q / rail).powi(4);
            }
        }
    }

    terms
}

pub fn compute_penalty_total(x: &[f64], data: &ObjectiveData) -> f64 {
    penalty_terms(x, data).into_iter().sum()
}

pub fn compute_fitness_penalties_ref(x: &[f64], data: &ObjectiveData) -> f64 {
    try_compute_fitness_penalties_ref(x, data).unwrap_or(f64::INFINITY)
}

/// Compute a scalar validation score while retaining a typed stop refusal.
pub fn try_compute_fitness_penalties_ref(
    x: &[f64],
    data: &ObjectiveData,
) -> Result<f64, ValidationScoreRefusal> {
    let _evaluation_guard = begin_controlled_evaluation(data).map_err(|()| {
        if data.terminal_stop_requested() {
            ValidationScoreRefusal::TerminalStop
        } else {
            ValidationScoreRefusal::NonTerminal
        }
    })?;
    Ok(compute_fitness_penalties_uncontrolled(x, data))
}

fn compute_fitness_penalties_uncontrolled(x: &[f64], data: &ObjectiveData) -> f64 {
    let Ok(projected) = super::resolution_guard::guarded_parameters(x, data, |_| {}) else {
        return f64::INFINITY;
    };
    let x = projected.as_ref();
    let fit = compute_base_fitness(x, data);

    // When penalties are enabled (weights > 0), add them to the base fit so that
    // optimizers without nonlinear constraints can still respect our limits.
    let mut penalized = fit;
    for term in penalty_terms(x, data) {
        penalized += term;
    }

    penalized
}

fn begin_controlled_evaluation(
    data: &ObjectiveData,
) -> Result<Option<super::run_control::ObjectiveEvaluationGuard>, ()> {
    let prepared = data.prepared();
    let Some(control) = prepared.run_control.as_ref() else {
        return Ok(None);
    };
    let component_count = data
        .multi_objective
        .as_ref()
        .map_or(1, |multi| multi.objectives.len().max(1));
    control
        .begin_evaluation(prepared.evaluation_stage, component_count)
        .map(Some)
        .ok_or(())
}

/// Compute objective function value including penalty terms for constraints
///
/// NLOPT-compatible wrapper that takes `&mut ObjectiveData` (required by NLOPT's callback
/// signature). Delegates to `compute_fitness_penalties_ref`.
///
/// # Arguments
/// * `x` - Parameter vector
/// * `_gradient` - Gradient vector (unused, for NLOPT compatibility)
/// * `data` - Objective data containing penalty weights and parameters
///
/// # Returns
/// Base fitness value plus weighted penalty terms
pub fn compute_fitness_penalties(
    x: &[f64],
    _gradient: Option<&mut [f64]>,
    data: &mut ObjectiveData,
) -> f64 {
    compute_fitness_penalties_ref(x, data)
}

/// Extract sorted center frequencies from parameter vector and compute adjacent spacings in octaves.
pub fn compute_sorted_freqs_and_adjacent_octave_spacings(
    x: &[f64],
    peq_model: PeqModel,
) -> (Vec<f64>, Vec<f64>) {
    let n = crate::param_utils::num_filters(x, peq_model);
    let mut freqs: Vec<f64> = Vec::with_capacity(n);
    for i in 0..n {
        let params = crate::param_utils::get_filter_params(x, i, peq_model);
        freqs.push(10f64.powf(params.freq));
    }
    freqs.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
    let spacings: Vec<f64> = if freqs.len() < 2 {
        Vec::new()
    } else {
        freqs
            .windows(2)
            .map(|w| (w[1].max(1e-9) / w[0].max(1e-9)).log2().abs())
            .collect()
    };
    (freqs, spacings)
}

#[cfg(test)]
mod spacing_diag_tests {

    use super::super::compute_sorted_freqs_and_adjacent_octave_spacings;

    #[test]
    fn adjacent_octave_spacings_basic() {
        // x: [f,q,g, f,q,g, f,q,g]
        let x = [
            100f64.log10(),
            1.0,
            0.0,
            200f64.log10(),
            1.0,
            0.0,
            400f64.log10(),
            1.0,
            0.0,
        ];
        use crate::PeqModel;
        let (_freqs, spacings) =
            compute_sorted_freqs_and_adjacent_octave_spacings(&x, PeqModel::Pk);
        assert!((spacings[0] - 1.0).abs() < 1e-12);
        assert!((spacings[1] - 1.0).abs() < 1e-12);
    }
}

#[cfg(test)]
mod smoothness_penalty_edge_tests {
    use super::{SmoothnessPenaltyConfig, compute_smoothness_penalty};
    use ndarray::Array1;

    #[test]
    fn smoothness_penalty_short_array_returns_zero() {
        let y = Array1::from_vec(vec![1.0, 2.0]);
        let freqs = Array1::from_vec(vec![100.0, 200.0]);
        let cfg = SmoothnessPenaltyConfig {
            tv2_weight: 1.0,
            ..Default::default()
        };
        assert_eq!(
            compute_smoothness_penalty(&y, &freqs, 20.0, 20000.0, &cfg),
            0.0
        );
    }

    #[test]
    fn smoothness_penalty_mismatched_lengths_returns_zero() {
        let y = Array1::from_vec(vec![1.0, 2.0, 3.0]);
        let freqs = Array1::from_vec(vec![100.0, 200.0]);
        let cfg = SmoothnessPenaltyConfig {
            tv2_weight: 1.0,
            ..Default::default()
        };
        assert_eq!(
            compute_smoothness_penalty(&y, &freqs, 20.0, 20000.0, &cfg),
            0.0
        );
    }

    #[test]
    fn smoothness_penalty_negative_or_zero_freqs_skipped() {
        let freqs = Array1::from_vec(vec![0.0, 100.0, 200.0, 300.0]);
        let y = Array1::from_vec(vec![0.0, 0.0, 1.0, 0.0]);
        let cfg = SmoothnessPenaltyConfig {
            tv2_weight: 1.0,
            ..Default::default()
        };
        let p = compute_smoothness_penalty(&y, &freqs, 20.0, 20000.0, &cfg);
        assert!(p.is_finite() && p >= 0.0);
    }

    #[test]
    fn smoothness_penalty_is_invariant_to_log_grid_density() {
        let evaluate = |count| {
            let frequencies = Array1::<f64>::logspace(10.0, 1.0, 4.0, count);
            let response = frequencies.mapv(|frequency| frequency.ln().powi(2));
            compute_smoothness_penalty(
                &response,
                &frequencies,
                10.0,
                10_000.0,
                &SmoothnessPenaltyConfig {
                    tv2_weight: 1.0,
                    exponent: 2.0,
                    ..Default::default()
                },
            )
        };

        let coarse = evaluate(17);
        let dense = evaluate(257);
        assert!(coarse > 0.0 && dense > 0.0);
        assert!(
            (coarse - dense).abs() <= 1e-10 * coarse.max(dense),
            "coarse={coarse}, dense={dense}"
        );
    }

    #[test]
    fn smoothness_penalty_custom_exponent() {
        let n = 50;
        let freqs = Array1::<f64>::logspace(10.0, 1.0, 4.0, n);
        let y = freqs.mapv(|f| 2.0 * (f.log10() * 10.0).sin());
        let cfg1 = SmoothnessPenaltyConfig {
            tv2_weight: 1.0,
            exponent: 1.5,
            ..Default::default()
        };
        let cfg2 = SmoothnessPenaltyConfig {
            tv2_weight: 1.0,
            exponent: 2.0,
            ..Default::default()
        };
        let p1 = compute_smoothness_penalty(&y, &freqs, 20.0, 20000.0, &cfg1);
        let p2 = compute_smoothness_penalty(&y, &freqs, 20.0, 20000.0, &cfg2);
        assert!(p1 > 0.0 && p2 > 0.0);
        assert!(
            p2 > p1 * 0.5,
            "exponent=2.0 should produce comparable or larger penalty than 1.5"
        );
    }

    #[test]
    fn smoothness_penalty_nonuniform_dx_skipped() {
        // Non-monotonic log-freq grid (dx_fwd <= 0 or dx_bwd <= 0)
        let freqs = Array1::from_vec(vec![100.0, 200.0, 150.0, 400.0]);
        let y = Array1::from_vec(vec![0.0, 1.0, 0.5, 0.0]);
        let cfg = SmoothnessPenaltyConfig {
            tv2_weight: 1.0,
            ..Default::default()
        };
        let p = compute_smoothness_penalty(&y, &freqs, 20.0, 20000.0, &cfg);
        assert!(p.is_finite() && p >= 0.0);
    }

    #[test]
    fn smoothness_penalty_schroeder_boundary() {
        // Create a curve with a sharp bend at exactly 200 Hz (the Schroeder boundary)
        let n = 100;
        let freqs = Array1::logspace(10.0, 1.0, 4.0, n);
        let y = freqs.mapv(|f: f64| {
            let ratio = f / 200.0_f64;
            if f < 200.0_f64 {
                5.0_f64 * ratio.log10()
            } else {
                -5.0_f64 * ratio.log10()
            }
        });
        let cfg_modal = SmoothnessPenaltyConfig {
            tv2_weight: 1.0,
            schroeder_hz: Some(200.0),
            modal_weight_scale: 0.0,
            exponent: 1.0,
        };
        let cfg_strict = SmoothnessPenaltyConfig {
            tv2_weight: 1.0,
            schroeder_hz: None,
            modal_weight_scale: 1.0,
            exponent: 1.0,
        };
        let p_modal = compute_smoothness_penalty(&y, &freqs, 20.0, 20000.0, &cfg_modal);
        let p_strict = compute_smoothness_penalty(&y, &freqs, 20.0, 20000.0, &cfg_strict);
        assert!(
            p_modal <= p_strict,
            "modal exemption at schroeder boundary should reduce or equal penalty: modal={p_modal}, strict={p_strict}"
        );
    }

    #[test]
    fn smoothness_penalty_outside_range_returns_zero() {
        let freqs = Array1::from_vec(vec![100.0, 200.0, 300.0, 400.0]);
        let y = Array1::from_vec(vec![0.0, 1.0, 0.0, 1.0]);
        let cfg = SmoothnessPenaltyConfig {
            tv2_weight: 1.0,
            ..Default::default()
        };
        // min_freq > max_freq in data range → no points evaluated
        let p = compute_smoothness_penalty(&y, &freqs, 500.0, 600.0, &cfg);
        assert_eq!(p, 0.0, "outside range should produce zero penalty");
    }
}

#[cfg(test)]
mod multi_objective_and_base_fitness_tests {
    use super::{
        EVALUATION_SCRATCH, ObjectiveData, RESPONSE_COMPUTATIONS, compute_base_fitness,
        compute_base_fitness_single, compute_fitness_penalties, compute_fitness_penalties_ref,
        compute_multi_objective_fitness, compute_pareto_objectives,
        compute_sorted_freqs_and_adjacent_octave_spacings, penalty_terms, variance_penalized_loss,
    };
    use crate::MultiObjectiveData;
    use crate::ObjectiveDataBuilder;
    use crate::PeqModel;
    use crate::loss::epa::score::EpaConfig;
    use crate::loss::{HeadphoneLossData, LossType, SpeakerLossData};
    use crate::roomeq::MultiMeasurementStrategy;
    use ndarray::Array1;
    use std::num::NonZeroUsize;
    use std::sync::Arc;

    fn freqs() -> Array1<f64> {
        Array1::from_vec(vec![100.0, 200.0, 400.0, 800.0, 1600.0])
    }

    #[test]
    fn realized_response_matches_existing_peq_objectives() {
        let parameters = vec![500.0_f64.log10(), 1.0, 3.0];
        for loss in [
            LossType::SpeakerFlat,
            LossType::HeadphoneFlat,
            LossType::SpeakerFlatAsymmetric,
            LossType::Epa,
        ] {
            let data = base_objective(loss);
            let response =
                crate::x2peq::x2spl(&data.freqs, &parameters, data.srate, data.peq_model);
            let actual = super::compute_response_fitness(&[response], &data)
                .expect("single-curve objective supports realized magnitude");
            let existing = compute_base_fitness(&parameters, &data);
            assert!(actual.is_finite() && existing.is_finite());
            assert!(
                (actual - existing).abs() < 1e-10,
                "{loss:?}: {actual} versus {existing}"
            );
        }
    }

    #[test]
    fn realized_response_scalarises_actual_seat_losses() {
        let mut first = base_objective(LossType::SpeakerFlat);
        first.deviation = Arc::new(Array1::zeros(5));
        let mut second = base_objective(LossType::SpeakerFlat);
        second.deviation = Arc::new(Array1::from_elem(5, 10.0));
        let responses = [Array1::zeros(5), Array1::zeros(5)];
        for (strategy, expected) in [
            (MultiMeasurementStrategy::Average, 5.0),
            (MultiMeasurementStrategy::WeightedSum, 1.0),
            (MultiMeasurementStrategy::Minimax, 10.0),
            (MultiMeasurementStrategy::VariancePenalized, 10.0),
            (MultiMeasurementStrategy::MinimaxUncertainty, 10.0),
        ] {
            let mut data = first.clone();
            data.multi_objective = Some(MultiObjectiveData {
                objectives: vec![first.clone(), second.clone()],
                strategy,
                weights: vec![0.9, 0.1],
                variance_lambda: 1.0,
                uncertainty_cvar_alpha: None,
            });
            let actual = super::compute_response_fitness(&responses, &data).unwrap();
            assert!(
                (actual - expected).abs() < 1e-10,
                "{strategy:?}: {actual} versus {expected}"
            );
            assert_eq!(
                super::compute_response_fitness(&responses[..1], &data),
                Some(f64::INFINITY)
            );
            let invalid = [Array1::zeros(5), Array1::from_elem(5, f64::NAN)];
            assert_eq!(
                super::compute_response_fitness(&invalid, &data),
                Some(f64::INFINITY)
            );
        }
    }

    #[test]
    fn two_seat_zero_ten_db_risk_prefers_documented_midpoint() {
        let unbalanced = variance_penalized_loss([(0.0, 0.5), (10.0, 0.5)], 1.0);
        let balanced = variance_penalized_loss([(5.0, 0.5), (5.0, 0.5)], 1.0);
        assert!((unbalanced - 30.0).abs() < 1e-12);
        assert!((balanced - 5.0).abs() < 1e-12);
        assert!(balanced < unbalanced);
    }

    #[test]
    fn variance_penalized_risk_honors_seat_weights() {
        let equal = variance_penalized_loss([(0.0, 0.5), (10.0, 0.5)], 0.0);
        let primary_weighted = variance_penalized_loss([(0.0, 0.9), (10.0, 0.1)], 0.0);
        assert!((equal - 5.0).abs() < 1e-12);
        assert!((primary_weighted - 1.0).abs() < 1e-12);
    }

    #[test]
    fn prepared_flat_hot_path_does_not_smooth_signed_error_before_loss() {
        let mut alternating = base_objective(LossType::SpeakerFlat);
        alternating.smooth = true;
        alternating.smooth_n = 2;
        alternating.deviation = Arc::new(Array1::from_vec(vec![6.0, -6.0, 6.0, -6.0, 6.0]));

        let mut constant = base_objective(LossType::SpeakerFlat);
        constant.smooth = true;
        constant.smooth_n = 2;
        constant.deviation = Arc::new(Array1::from_elem(5, 6.0));

        let alternating_loss = compute_base_fitness_single(&x(), &alternating);
        let constant_loss = compute_base_fitness_single(&x(), &constant);
        assert!((alternating_loss - constant_loss).abs() < 1e-12);
    }

    fn x() -> Vec<f64> {
        // one peak filter at 500 Hz, Q=1, gain=0 (neutral)
        vec![500f64.log10(), 1.0, 0.0]
    }

    fn base_objective(loss_type: LossType) -> ObjectiveData {
        let f = freqs();
        let n = f.len();
        ObjectiveDataBuilder::new(
            f,
            Array1::from_elem(n, 80.0),
            Array1::from_elem(n, 5.0),
            48000.0,
            PeqModel::Pk,
            loss_type,
        )
        .min_spacing_oct(0.5)
        .max_db(12.0)
        .min_db(0.0)
        .freq_range(20.0, 20000.0)
        .smoothing(false, 0)
        .build()
        .expect("valid base objective")
    }

    fn multi_objective(strategy: MultiMeasurementStrategy) -> MultiObjectiveData {
        let obj = base_objective(LossType::SpeakerFlat);
        MultiObjectiveData {
            objectives: vec![obj.clone(), obj.clone()],
            strategy,
            weights: vec![0.4, 0.6],
            variance_lambda: 0.5,
            uncertainty_cvar_alpha: Some(0.5),
        }
    }

    #[test]
    fn multi_objective_strategies() {
        let mo = multi_objective(MultiMeasurementStrategy::Average);
        let avg = compute_multi_objective_fitness(&x(), &mo);
        assert!(avg.is_finite());

        let mo = multi_objective(MultiMeasurementStrategy::WeightedSum);
        let ws = compute_multi_objective_fitness(&x(), &mo);
        assert!(ws.is_finite());

        let mo = multi_objective(MultiMeasurementStrategy::Minimax);
        let mm = compute_multi_objective_fitness(&x(), &mo);
        assert!(mm.is_finite());

        let mo = multi_objective(MultiMeasurementStrategy::VariancePenalized);
        let vp = compute_multi_objective_fitness(&x(), &mo);
        assert!(vp.is_finite());

        let mo = multi_objective(MultiMeasurementStrategy::MinimaxUncertainty);
        let mmu = compute_multi_objective_fitness(&x(), &mo);
        assert!(mmu.is_finite());
    }

    #[test]
    fn multi_objective_reuses_response_for_shared_frequency_grid() {
        let objective = base_objective(LossType::SpeakerFlat);
        let mo = MultiObjectiveData {
            objectives: vec![objective.clone(), objective.clone(), objective],
            weights: vec![1.0 / 3.0; 3],
            strategy: MultiMeasurementStrategy::WeightedSum,
            variance_lambda: 0.5,
            uncertainty_cvar_alpha: Some(0.5),
        };

        EVALUATION_SCRATCH.with(|slot| {
            let mut scratch = slot.borrow_mut();
            scratch.response_parameters.clear();
            scratch.response_freqs = None;
        });
        RESPONSE_COMPUTATIONS.with(|count| count.set(0));

        let loss = compute_multi_objective_fitness(&x(), &mo);

        assert!(loss.is_finite());
        RESPONSE_COMPUTATIONS.with(|count| {
            assert_eq!(
                count.get(),
                1,
                "one candidate response should serve every aligned measurement"
            );
        });
    }

    #[test]
    fn compute_pareto_objectives_scalar_and_multi() {
        let obj = base_objective(LossType::SpeakerFlat);
        let scalar = compute_pareto_objectives(&x(), &obj);
        assert_eq!(scalar.len(), 1);

        let mut multi = obj.clone();
        multi.multi_objective = Some(multi_objective(MultiMeasurementStrategy::WeightedSum));
        let vec = compute_pareto_objectives(&x(), &multi);
        assert_eq!(vec.len(), 2);
    }

    #[test]
    fn base_fitness_speaker_flat_and_asymmetric() {
        let obj = base_objective(LossType::SpeakerFlat);
        assert!(compute_base_fitness_single(&x(), &obj).is_finite());

        let asym = ObjectiveDataBuilder::speaker_flat_asymmetric(
            freqs(),
            Array1::from_elem(freqs().len(), 80.0),
            Array1::from_elem(freqs().len(), 5.0),
            48000.0,
            PeqModel::Pk,
        )
        .max_db(12.0)
        .min_db(0.0)
        .freq_range(20.0, 20000.0)
        .smoothing(false, 0)
        .null_suppression(Array1::from_elem(freqs().len(), 1.0))
        .build()
        .expect("valid asymmetric objective");
        assert!(compute_base_fitness_single(&x(), &asym).is_finite());
    }

    #[test]
    fn null_boost_cost_preserves_peq_fir_parity_and_cut_preference() {
        for loss_type in [LossType::SpeakerFlat, LossType::SpeakerFlatAsymmetric] {
            let frequencies = freqs();
            let make = |mask| {
                ObjectiveDataBuilder::new(
                    frequencies.clone(),
                    Array1::zeros(frequencies.len()),
                    Array1::from_elem(frequencies.len(), 5.0),
                    48_000.0,
                    PeqModel::Pk,
                    loss_type,
                )
                .freq_range(20.0, 20_000.0)
                .null_suppression(Array1::from_elem(frequencies.len(), mask))
                .build()
                .unwrap()
            };
            let null = make(0.0);
            let broad = make(1.0);
            let identity = x();
            let boost = vec![500_f64.log10(), 1.0, 3.0];
            let cut = vec![500_f64.log10(), 1.0, -3.0];
            assert_eq!(compute_base_fitness_single(&identity, &null), 0.0);
            assert!(compute_base_fitness_single(&boost, &null) > 0.0);
            for candidate in [&identity, &boost, &cut] {
                let response = crate::x2peq::x2spl(&frequencies, candidate, 48_000.0, PeqModel::Pk);
                let peq = compute_base_fitness_single(candidate, &null);
                let fir = super::compute_response_fitness(&[response], &null).unwrap();
                assert!((peq - fir).abs() < 1e-12, "{loss_type:?}: {peq} != {fir}");
            }
            let correction = Array1::from_elem(frequencies.len(), -3.0);
            assert_eq!(
                null.prepared()
                    .null_boost
                    .as_ref()
                    .unwrap()
                    .evaluate_null_boost(&correction),
                0.0
            );
            assert_eq!(
                broad
                    .prepared()
                    .null_boost
                    .as_ref()
                    .unwrap()
                    .evaluate_null_boost(&Array1::from_elem(frequencies.len(), 3.0)),
                0.0
            );
            assert!(
                compute_base_fitness_single(&boost, &broad)
                    < compute_base_fitness_single(&identity, &broad),
                "broad correctable dips should still reward useful boost"
            );
        }
    }

    #[test]
    fn base_fitness_missing_data_rejected_by_builder() {
        let f = freqs();
        let n = f.len();
        let core = |loss_type| {
            ObjectiveDataBuilder::new(
                f.clone(),
                Array1::from_elem(n, 80.0),
                Array1::from_elem(n, 5.0),
                48000.0,
                PeqModel::Pk,
                loss_type,
            )
            .max_db(12.0)
            .min_db(0.0)
            .freq_range(20.0, 20000.0)
        };

        assert!(core(LossType::DriversFlat).build().is_err());
        assert!(core(LossType::MultiSubFlat).build().is_err());
        assert!(core(LossType::SpeakerScore).build().is_err());
        assert!(core(LossType::HeadphoneScore).build().is_err());
    }

    #[test]
    fn base_fitness_speaker_score_and_headphone_score() {
        let f = Array1::from_vec(vec![100.0, 1000.0, 10000.0]);
        let n = f.len();
        let x = vec![2.0, 1.0, 0.0];

        let speaker = ObjectiveDataBuilder::speaker_score(
            f.clone(),
            Array1::from_elem(n, 80.0),
            Array1::from_elem(n, 5.0),
            48000.0,
            PeqModel::Pk,
            SpeakerLossData {
                on: Array1::from_vec(vec![80.0, 85.0, 82.0]),
                lw: Array1::from_vec(vec![81.0, 84.0, 83.0]),
                sp: Array1::from_vec(vec![78.0, 82.0, 80.0]),
                pir: Array1::from_vec(vec![80.5, 84.0, 82.5]),
            },
        )
        .max_db(12.0)
        .min_db(0.0)
        .freq_range(20.0, 20000.0)
        .smoothing(false, 0)
        .build()
        .expect("valid speaker-score objective");
        assert!(compute_base_fitness_single(&x, &speaker).is_finite());
        let parameters = vec![500.0_f64.log10(), 1.0, 3.0];
        let realized = crate::x2peq::x2spl(
            &speaker.freqs,
            &parameters,
            speaker.srate,
            speaker.peq_model,
        );
        let actual = super::compute_response_fitness(&[realized], &speaker).unwrap();
        assert!((actual - compute_base_fitness(&parameters, &speaker)).abs() < 1e-10);

        let headphone = ObjectiveDataBuilder::headphone_score(
            f.clone(),
            Array1::from_elem(n, 80.0),
            Array1::from_elem(n, 5.0),
            48000.0,
            PeqModel::Pk,
            HeadphoneLossData::new(false, 0),
        )
        .input_curve(crate::Curve {
            freq: f.clone(),
            spl: Array1::from_elem(n, 80.0),
            phase: None,
            ..Default::default()
        })
        .max_db(12.0)
        .min_db(0.0)
        .freq_range(20.0, 20000.0)
        .smoothing(false, 0)
        .build()
        .expect("valid headphone-score objective");
        assert!(compute_base_fitness_single(&x, &headphone).is_finite());
    }

    #[test]
    fn base_fitness_epa() {
        let mut epa = base_objective(LossType::Epa);
        epa.epa_config = Some(EpaConfig::default());
        assert!(compute_base_fitness_single(&x(), &epa).is_finite());
    }

    #[test]
    fn base_fitness_multi_objective_delegation() {
        let mut obj = base_objective(LossType::SpeakerFlat);
        obj.multi_objective = Some(multi_objective(MultiMeasurementStrategy::Minimax));
        let loss = compute_base_fitness(&x(), &obj);
        assert!(loss.is_finite());
    }

    #[test]
    fn fitness_penalties_add_penalty_terms() {
        let mut obj = base_objective(LossType::SpeakerFlat);
        obj.penalty_w_ceiling = 1.0;
        obj.penalty_w_spacing = 1.0;
        obj.min_db = 1.0;
        obj.penalty_w_mingain = 1.0;
        let penalized = compute_fitness_penalties_ref(&x(), &obj);
        let base = compute_base_fitness(&x(), &obj);
        assert!(penalized >= base);

        // Drivers loss skips PEQ-specific penalties.
        obj.loss_type = LossType::DriversFlat;
        let drivers_penalized = compute_fitness_penalties_ref(&x(), &obj);
        assert!(
            drivers_penalized.is_infinite()
                || drivers_penalized == compute_base_fitness(&x(), &obj)
        );
    }

    #[test]
    fn q_rail_penalty_preserves_gain_sign_neutral_filters_and_layouts() {
        let mut data = base_objective(LossType::SpeakerFlat);
        data.q_rail_penalty = Some((6.0, 0.02));
        let peak = [500.0_f64.log10(), 6.0, -12.0];
        assert!((penalty_terms(&peak, &data)[3] - 0.24).abs() < 1e-12);
        let broad = [peak[0], 3.0, -12.0];
        assert!((penalty_terms(&broad, &data)[3] - 0.015).abs() < 1e-12);
        assert_eq!(
            penalty_terms(&[peak[0], 6.0, 12.0], &data)[3],
            penalty_terms(&peak, &data)[3]
        );
        let mut with_neutral = peak.to_vec();
        with_neutral.extend([peak[0], 6.0, 0.0]);
        assert_eq!(
            penalty_terms(&with_neutral, &data)[3],
            penalty_terms(&peak, &data)[3]
        );
        data.peq_model = PeqModel::LsPkHs;
        assert_eq!(
            penalty_terms(
                &[peak[0], 6.0, -12.0, peak[0], 6.0, 0.0, peak[0], 6.0, 12.0],
                &data
            )[3],
            0.0
        );
        data.peq_model = PeqModel::Free;
        assert!(
            (penalty_terms(&[11.0, peak[0], 6.0, -12.0], &data)[3] - 0.24).abs() < 1e-12,
            "matched peaks must not bypass the same rail complexity cost"
        );
        assert_eq!(penalty_terms(&[11.0, peak[0], 6.0, 0.0], &data)[3], 0.0);
        data.loss_type = LossType::DriversFlat;
        assert_eq!(penalty_terms(&[], &data)[3], 0.0);
    }

    #[test]
    fn epa_spectral_regression_matches_reference_and_peq_fir_paths() {
        let frequencies = Array1::logspace(10.0, 20.0_f64.log10(), 20000.0_f64.log10(), 401);
        let mut data = ObjectiveDataBuilder::speaker_flat(
            frequencies.clone(),
            Array1::zeros(401),
            Array1::from_elem(401, 2.0),
            48000.0,
            PeqModel::Pk,
        )
        .freq_range(20.0, 20000.0)
        .build()
        .unwrap();
        let x = [1000.0_f64.log10(), 1.0, -6.0];
        let response = crate::x2peq::x2spl(&frequencies, &x, 48000.0, PeqModel::Pk);
        let unpenalized = compute_base_fitness(&x, &data);
        data.epa_flatness_regression_weight = 1.0;
        data.epa_config = Some(EpaConfig {
            flatness_erb_weight: 0.4,
            flatness_band_weight: 0.6,
            ..Default::default()
        });
        data.prepared = Arc::new(std::sync::OnceLock::new());
        let config = data.epa_config.as_ref().unwrap();
        let expected_cost = (crate::loss::epa::score::epa_flatness(
            &frequencies,
            &(&response - &*data.deviation),
            20.0,
            20000.0,
            config,
        ) - crate::loss::epa::score::epa_flatness(
            &frequencies,
            &data.deviation,
            20.0,
            20000.0,
            config,
        ))
        .max(0.0);
        assert!(expected_cost > 0.0);
        let penalized = compute_base_fitness(&x, &data);
        assert!((penalized - unpenalized - expected_cost).abs() < 1e-10);
        assert!(
            (super::compute_response_fitness(&[response], &data).unwrap() - penalized).abs()
                < 1e-10
        );
        assert!((compute_base_fitness(&[], &data) - 2.0).abs() < 1e-10);
    }

    #[test]
    fn epa_spectral_regression_cannot_be_hidden_by_null_suppression() {
        let frequencies = Array1::logspace(10.0, 20.0_f64.log10(), 20000.0_f64.log10(), 101);
        let mut data = ObjectiveDataBuilder::speaker_flat(
            frequencies,
            Array1::zeros(101),
            Array1::from_elem(101, 2.0),
            48000.0,
            PeqModel::Pk,
        )
        .freq_range(20.0, 20000.0)
        .build()
        .unwrap();
        data.null_suppression = Some(Arc::new(Array1::zeros(101)));
        data.epa_flatness_regression_weight = 1.0;
        let score = |correction: f64| {
            super::compute_response_fitness(&[Array1::from_elem(101, correction)], &data).unwrap()
        };
        assert!(score(0.0).abs() < 1e-10);
        assert!((score(-1.0) - 1.0).abs() < 1e-10);
        // The independent null-boost term still charges positive correction;
        // EPA adds nothing when the target residual is exactly zero.
        assert!((score(2.0) - 2.0).abs() < 1e-10);
    }

    #[test]
    fn epa_spectral_regression_uses_each_seat_baseline_before_aggregation() {
        let mut first = base_objective(LossType::SpeakerFlat);
        first.deviation = Arc::new(Array1::from_elem(5, 2.0));
        first.epa_flatness_regression_weight = 1.0;
        let mut second = base_objective(LossType::SpeakerFlat);
        second.deviation = Arc::new(Array1::from_elem(5, 4.0));
        second.epa_flatness_regression_weight = 1.0;
        let responses = [Array1::from_elem(5, -1.0), Array1::from_elem(5, -3.0)];
        // First seat: raw loss3 plus EPA regression1. Second: loss7 plus3.
        for (strategy, expected) in [
            (MultiMeasurementStrategy::Average, 7.0),
            (MultiMeasurementStrategy::WeightedSum, 8.5),
            (MultiMeasurementStrategy::Minimax, 10.0),
        ] {
            let mut data = first.clone();
            let mut multi = multi_objective(strategy);
            multi.objectives = vec![first.clone(), second.clone()];
            multi.weights = vec![0.25, 0.75];
            data.multi_objective = Some(multi);
            let score = super::compute_response_fitness(&responses, &data).unwrap();
            assert!((score - expected).abs() < 1e-10, "{strategy:?}: {score}");
        }
    }

    #[test]
    fn q_rail_shared_penalty_is_added_once_for_scalar_and_pareto_seats() {
        let mut data = base_objective(LossType::SpeakerFlat);
        data.q_rail_penalty = Some((6.0, 0.02));
        let x = [500.0_f64.log10(), 6.0, -12.0];
        data.multi_objective = Some(multi_objective(MultiMeasurementStrategy::Minimax));
        let unpenalized = compute_base_fitness(&x, &data);
        // Other configured penalty terms are kept separate, so the test catches
        // seat replication or scalarization of this shared parameter cost.
        data.penalty_w_ceiling = 0.0;
        data.penalty_w_spacing = 0.0;
        data.penalty_w_mingain = 0.0;
        assert!((compute_fitness_penalties_ref(&x, &data) - unpenalized - 0.24).abs() < 1e-10);
        let pareto = compute_pareto_objectives(&x, &data);
        for (actual, seat) in pareto
            .iter()
            .zip(&data.multi_objective.as_ref().unwrap().objectives)
        {
            assert!((actual - compute_base_fitness_single(&x, seat) - 0.24).abs() < 1e-10);
        }
    }

    #[test]
    fn q_rail_cost_does_not_ban_a_supported_narrow_defect() {
        let frequencies = Array1::logspace(10.0, 20.0_f64.log10(), 2000.0_f64.log10(), 401);
        let narrow = [80.0_f64.log10(), 6.0, -12.0];
        let broad = [narrow[0], 3.0, narrow[2]];
        let deviation = crate::x2peq::x2spl(&frequencies, &narrow, 48000.0, PeqModel::Pk);
        let mut data = ObjectiveDataBuilder::speaker_flat(
            frequencies.clone(),
            Array1::zeros(frequencies.len()),
            deviation,
            48000.0,
            PeqModel::Pk,
        )
        .freq_range(20.0, 2000.0)
        .build()
        .unwrap();
        data.q_rail_penalty = Some((6.0, 0.02));
        assert!(
            compute_fitness_penalties_ref(&narrow, &data)
                < compute_fitness_penalties_ref(&broad, &data)
        );
        assert!(
            compute_fitness_penalties_ref(&narrow, &data)
                < compute_fitness_penalties_ref(&[], &data)
        );
    }

    #[test]
    fn fitness_penalties_wrapper_matches_ref() {
        let mut obj = base_objective(LossType::SpeakerFlat);
        let ref_val = compute_fitness_penalties_ref(&x(), &obj);
        let wrapped_val = compute_fitness_penalties(&x(), None, &mut obj);
        assert_eq!(ref_val, wrapped_val);
    }

    #[test]
    fn controlled_scalar_scoring_enforces_the_candidate_budget() {
        let source = base_objective(LossType::SpeakerFlat);
        let source_prepared = source.prepared();
        let control =
            super::super::run_control::OptimizerRunControl::new(NonZeroUsize::new(1).unwrap());
        let controlled = source.with_run_control(control.clone());

        assert!(compute_fitness_penalties_ref(&x(), &controlled).is_finite());
        assert!(compute_fitness_penalties_ref(&x(), &controlled).is_infinite());
        let snapshot = control.snapshot();
        assert_eq!(snapshot.evaluations_started, 1);
        assert_eq!(snapshot.evaluations_completed, 1);
        assert_eq!(snapshot.evaluations_refused, 1);
        assert!(source.prepared().run_control.is_none());
        assert!(std::ptr::eq(source_prepared, source.prepared()));
        assert!(!Arc::ptr_eq(&source.prepared, &controlled.prepared));
    }

    #[test]
    fn controlled_pareto_scoring_counts_one_candidate_and_all_components() {
        let objective = base_objective(LossType::SpeakerFlat);
        let mut source = objective.clone();
        source.multi_objective = Some(MultiObjectiveData {
            objectives: vec![objective.clone(), objective],
            weights: vec![0.5, 0.5],
            strategy: MultiMeasurementStrategy::WeightedSum,
            variance_lambda: 0.0,
            uncertainty_cvar_alpha: None,
        });
        let control =
            super::super::run_control::OptimizerRunControl::new(NonZeroUsize::new(1).unwrap());
        let controlled = source.with_run_control(control.clone());

        let values = compute_pareto_objectives(&x(), &controlled);
        assert_eq!(values.len(), 2);
        assert!(values.iter().all(|value| value.is_finite()));
        let refused = compute_pareto_objectives(&x(), &controlled);
        assert_eq!(refused, vec![f64::INFINITY; 2]);
        let snapshot = control.snapshot();
        assert_eq!(snapshot.evaluations_started, 1);
        assert_eq!(snapshot.component_evaluations_started, 2);
        assert_eq!(snapshot.component_evaluations_completed, 2);
        assert_eq!(snapshot.evaluations_refused, 1);
    }

    #[test]
    fn sorted_freqs_and_spacings_one_filter() {
        let (freqs, spacings) =
            compute_sorted_freqs_and_adjacent_octave_spacings(&x(), PeqModel::Pk);
        assert_eq!(freqs.len(), 1);
        assert!(spacings.is_empty());
    }

    #[test]
    fn sorted_freqs_and_spacings_two_filters() {
        // two peak filters at 100 Hz and 400 Hz
        let params = vec![100f64.log10(), 1.0, 0.0, 400f64.log10(), 1.0, 0.0];
        let (freqs, spacings) =
            compute_sorted_freqs_and_adjacent_octave_spacings(&params, PeqModel::Pk);
        assert_eq!(freqs.len(), 2);
        assert_eq!(spacings.len(), 1);
        assert!((spacings[0] - 2.0).abs() < 1e-12);
    }

    #[test]
    fn pareto_objectives_match_scalarised_plus_shared_penalty() {
        // compute_pareto_objectives must agree with the scalarised base plus
        // the shared penalty, while evaluating each objective only once.
        let mut multi = base_objective(LossType::SpeakerFlat);
        multi.penalty_w_spacing = 1.0;
        multi.multi_objective = Some(multi_objective(MultiMeasurementStrategy::VariancePenalized));
        let objectives = compute_pareto_objectives(&x(), &multi);
        assert_eq!(objectives.len(), 2);
        let mo = multi.multi_objective.as_ref().expect("multi objective");
        let expected_base = compute_multi_objective_fitness(&x(), mo);
        let expected_penalized = compute_fitness_penalties_ref(&x(), &multi);
        let shared = (expected_penalized - expected_base).max(0.0);
        for (i, obj) in mo.objectives.iter().enumerate() {
            let base = compute_base_fitness_single(&x(), obj);
            assert!((objectives[i] - (base + shared)).abs() < 1e-12);
        }
    }
}

#[cfg(test)]
mod fractional_tail_cvar_tests {
    use super::fractional_tail_cvar_into;

    fn cvar(losses: &[f64], alpha: f64) -> f64 {
        fractional_tail_cvar_into(losses.to_vec().as_mut_slice(), alpha)
    }

    #[test]
    fn noninteger_mass_splits_one_sample_fractionally() {
        // Descending [10, 0, 0], alpha=0.5 covers mass 1.5: one full sample
        // plus half of the next, normalised by 1.5.
        let got = cvar(&[10.0, 0.0, 0.0], 0.5);
        assert!((got - 20.0 / 3.0).abs() < 1e-12, "got {got}");
    }

    #[test]
    fn input_order_does_not_matter() {
        assert!((cvar(&[0.0, 10.0, 0.0], 0.5) - 20.0 / 3.0).abs() < 1e-12);
    }

    #[test]
    fn ties_are_split_invariant() {
        // Any fractional split of equal values yields the same mean.
        assert!((cvar(&[5.0, 5.0, 5.0, 1.0], 0.5) - 5.0).abs() < 1e-12);
        assert!((cvar(&[7.0, 7.0, 7.0], 1.0 / 3.0) - 7.0).abs() < 1e-12);
    }

    #[test]
    fn alpha_endpoints_are_mean_and_max() {
        assert!((cvar(&[10.0, 0.0, 0.0], 1.0) - 10.0 / 3.0).abs() < 1e-12);
        assert!((cvar(&[10.0, 4.0, 0.0], f64::MIN_POSITIVE) - 10.0).abs() < 1e-12);
        assert!((cvar(&[10.0, 4.0, 0.0], 0.0) - 10.0).abs() < 1e-12);
    }

    #[test]
    fn integer_mass_matches_whole_sample_mean() {
        // alpha*N = 2 exactly: mean of the two worst.
        assert!((cvar(&[9.0, 7.0, 1.0, 0.0], 0.5) - 8.0).abs() < 1e-12);
    }

    #[test]
    fn degenerate_inputs_stay_worst_case() {
        assert_eq!(cvar(&[], 0.5), f64::INFINITY);
        assert_eq!(cvar(&[f64::INFINITY, 1.0], 0.5), f64::INFINITY);
        // NaN in the tail surfaces as worst-case, never as NaN.
        let got = cvar(&[f64::NAN, 1.0, 0.0], 0.5);
        assert!(got.is_infinite() && got > 0.0, "got {got}");
    }
}
