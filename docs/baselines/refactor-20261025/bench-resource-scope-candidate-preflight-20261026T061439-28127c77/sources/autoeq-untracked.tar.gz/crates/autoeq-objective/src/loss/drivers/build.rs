use super::crossover_type::CrossoverType;

/// Build crossover filters for a single driver
pub(super) fn build_crossover_filters_for_driver(
    driver_index: usize,
    n_drivers: usize,
    crossover_type: CrossoverType,
    crossover_freqs: &[f64],
    sample_rate: f64,
) -> Vec<(f64, crate::iir::Biquad)> {
    use crate::iir::{
        peq_butterworth_highpass, peq_butterworth_lowpass, peq_linkwitzriley_highpass,
        peq_linkwitzriley_lowpass,
    };

    let mut filters = Vec::new();
    if let CrossoverType::None = crossover_type {
        return filters;
    }
    if let CrossoverType::LinearPhase = crossover_type {
        return filters;
    }

    if driver_index > 0 {
        let xover_freq = crossover_freqs[driver_index - 1];
        let hp_peq = match crossover_type {
            CrossoverType::Butterworth2 => peq_butterworth_highpass(2, xover_freq, sample_rate),
            CrossoverType::Butterworth4 => peq_butterworth_highpass(4, xover_freq, sample_rate),
            CrossoverType::LinkwitzRiley2 => peq_linkwitzriley_highpass(2, xover_freq, sample_rate),
            CrossoverType::LinkwitzRiley4 => peq_linkwitzriley_highpass(4, xover_freq, sample_rate),
            CrossoverType::LinkwitzRiley8 => peq_linkwitzriley_highpass(8, xover_freq, sample_rate),
            CrossoverType::LinearPhase => vec![],
            CrossoverType::None => vec![],
        };
        filters.extend(hp_peq);
    }
    if driver_index < n_drivers - 1 {
        let xover_freq = crossover_freqs[driver_index];
        let lp_peq = match crossover_type {
            CrossoverType::Butterworth2 => peq_butterworth_lowpass(2, xover_freq, sample_rate),
            CrossoverType::Butterworth4 => peq_butterworth_lowpass(4, xover_freq, sample_rate),
            CrossoverType::LinkwitzRiley2 => peq_linkwitzriley_lowpass(2, xover_freq, sample_rate),
            CrossoverType::LinkwitzRiley4 => peq_linkwitzriley_lowpass(4, xover_freq, sample_rate),
            CrossoverType::LinkwitzRiley8 => peq_linkwitzriley_lowpass(8, xover_freq, sample_rate),
            CrossoverType::LinearPhase => vec![],
            CrossoverType::None => vec![],
        };
        filters.extend(lp_peq);
    }
    filters
}

pub(super) fn build_fir_crossover_coefficients_for_driver(
    driver_index: usize,
    n_drivers: usize,
    crossover_type: CrossoverType,
    crossover_freqs: &[f64],
    sample_rate: f64,
) -> Vec<Vec<f64>> {
    if !matches!(crossover_type, CrossoverType::LinearPhase) {
        return Vec::new();
    }

    let mut filters = Vec::new();
    if driver_index > 0 {
        let crossover = math_audio_iir_fir::FirCrossover::new(
            crossover_freqs[driver_index - 1],
            sample_rate,
            1,
            math_audio_iir_fir::DEFAULT_FIR_CROSSOVER_TAPS,
        );
        filters.push(crossover.highpass_coefficients());
    }
    if driver_index < n_drivers - 1 {
        let crossover = math_audio_iir_fir::FirCrossover::new(
            crossover_freqs[driver_index],
            sample_rate,
            1,
            math_audio_iir_fir::DEFAULT_FIR_CROSSOVER_TAPS,
        );
        filters.push(crossover.lowpass_coefficients().to_vec());
    }
    filters
}
