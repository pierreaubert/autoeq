# Audit implementation tracking

The original audit is `audit-20261018.md`. This checklist preserves its full scope.
Bug regressions are added and exercised before their production fixes.

| Finding | Required implementation and evidence | Status |
|---|---|---|
| C1 | Sound FIR type dispatch and FMA preconditions; supported-type numerical checks and unsupported-type boundary evidence | Implemented; release identity-boundary regression passed |
| C2 | Whole-program loudness retains early content beyond the production history limit; long-duration regression | Implemented; long-silence and continuous-hour regressions passed |
| C3 | Both gates apply to global and album energy; near-absolute-gate regression | Implemented; both-gate regression passed |
| C4 | Reject or compensate unsupported short/noisy decay fits; duration/SNR/headroom regressions | Implemented; short/noisy rejection and supported-fit regressions passed |
| C5 | Accurate bandlimited true-peak reconstruction with frequency/phase oracle and finite-tail handling | Implemented; frequency/phase and finite-tail regressions passed |
| C6 | Preserve arbitrary custom coefficients; scale/sample/block/reset convolution regressions | Implemented; f32/f64 mixed sample/block and reset regressions passed |
| C7 | Gain and arrival invariance for broadband clarity; explicit start support | Implemented; gain/delay and subnormal regressions passed |
| C8 | STFT finite-stream startup and drain correctness; every boundary/hop phase and reset | Implemented; exhaustive startup phases and finite drains passed |
| PERF1 | Public reusable Welch output API and warmed zero-allocation assertion | Implemented; public Welch allocation assertion passed |
| PERF2 | FIR preparation/reservation and defined oversized-block behavior; changing-size/reset allocation tests | Implemented; preparation/size/reset/oversize allocation assertions passed |
| PERF3 | SIMD general FIR block processing and asymmetric benchmark matrix | Implemented; direct-convolution equivalence passed; benchmark added |
| PERF4 | Reusable flattened resampling table with cached window; oracle and repeated-channel benchmark | Implemented; reusable-plan allocation and existing oracles passed |
| PERF5 | Buffered filtfilt, remove band copies, reuse decay output; long/multiband memory evidence | Implemented; 17.28 MB long-record bound and warmed zero-allocation check passed |
| PERF6 | Faster median selection and power-two path; equivalence tests and maintained benchmark | Implemented; selection equivalence passed; benchmark added |
| T1 | Required references fail visibly; manifest/comparison completeness checks | Implemented; missing-reference and record-gate regressions passed |
| T2 | Strong true-peak/STFT/RIR, analog quantitative, hull volume/nondegenerate assertions; selected mutation evidence | Implemented; independent analog oracle and stronger hull checks passed |
| T3 | Test-local temporary export directories and independent numerical assertions | Implemented; temporary export and numerical tests passed |
| T4 | Small-buffer driven/parameter/denormal/prepared allocation and timing coverage; latency distributions and budgets | Implemented; first-call allocation and all CPU-work budgets passed; wall distributions reported |
| Release | Workspace/crate changelogs, version/lockfile update, formatting, lint and full applicable QA | Verified; versions, lockfile, changelogs, formatting, lint, release tests and all six QA ladders passed |

## Execution evidence

- Before production fixes, the original implementation failed regressions for
  loudness history and gates, FIR scale equivalence, FIR SIMD type dispatch,
  true peaks, clarity delay/gain, STFT startup, RIR headroom, and missing QA references.
- The first broad release run passed the numerical regressions, independent analog
  oracle, hull properties/exports, and FIR/Welch/resampler allocation contracts.
  Its two failures were a contaminated concurrent timing measurement and an
  allocation fixture incorrectly requiring automatic acceptance of a short decay.
  Timing tests are now serialized with the existing budget intact; the memory
  fixture explicitly integrates its whole input to measure maximum buffer reuse.
- `cargo check --workspace --all-targets --offline` passed before the final additions.
- `cargo clippy --workspace --all-targets --offline -- -D warnings` passed after
  using the current compiler's fixed-size slice-chunk API.
- Fresh full release verification: `cargo test --workspace --tests --release
  --offline --no-fail-fast` exited 0: **2,043 passed, 0 failed, 1 ignored** across
  73 targets. Counts use each target's last summary, excluding nested optimizer
  subprocess summaries. The ignored case is the manual COBYLA convergence probe.
- `cargo fmt --all -- --check` and `git diff HEAD --check` passed.
- SHA-256 comparison of 654 source/build-configuration files found no changes
  between the final verification snapshot and completion checks; report-only
  edits are excluded from that comparison.
- All six affected-crate QA ladders passed: `just qa-analog`,
  `qa-convex-hull`, `qa-dsp`, `qa-iir-fir`, `qa-rir`, and `qa-mathqa`. These
  include the applicable doctests, coverage thresholds, benchmark builds,
  maintained benchmark execution, and crate-specific extras.
- `qa-mathqa-records` verified **13 executed comparisons** against the complete
  manifest using checked-in goldens. No live Wolfram computation is claimed.
- Workspace version is **0.5.4**. Affected crate versions and their lock entries
  agree: DSP 0.5.35, IIR/FIR 0.5.27, RIR 0.5.13, QA 0.5.4, analog 0.5.5,
  convex hull 0.3.4. Each has a dated changelog entry.
- Native runtime verification is on aarch64 macOS. CI now includes DSP/FIR
  AVX2+FMA, AVX2 without FMA, and scalar x86 feature configurations.
- Concurrent work added `DisplaySpectrogram` and its analysis tests; those changes
  were preserved and are outside this audit implementation's scope.

### Memory and scheduling measurements

- A 480,000-sample band/decay workspace originally requested 21,122,140 bytes
  after the first refactor. Reserving both reflected ends before appending the
  signal reduced requests to 17,282,140 bytes (retained: 17,281,260), matching the
  36-byte/sample buffer model plus small overhead. Repeated full/short/full calls
  allocate and reallocate zero times.
- A timing diagnostic observed 115,820,083 ns maximum wall time but only 1,784,042 ns
  maximum thread CPU time across all callbacks. Serialized tests alone cannot
  remove shared-host scheduling pauses. The 25% CPU work guard remains enforced;
  isolated runners opt into the additional 25% wall deadline with
  `MATH_AUDIO_ENFORCE_REALTIME=1`. Instrumented/debug builds report timing only.

### Additional issue exposed by T4 validation

The new driven 32-frame CPU check failed at 285,250 ns for six triode channels
against a 166,666 ns work budget. An independent f64 bisection regression then
failed on the original solver: after a grid transition to +6 V AC it held
+0.680757 V plate AC instead of the -199.591557 V load-line root. The old
finite-difference Newton/restart grid could spend both iteration budgets and
hold a physically incorrect preceding sample. The replacement uses the same
Koren equation, 5 mV residual tolerance, and 64-iteration cap, with an analytic
derivative and bracketed Newton/bisection steps. Independent slope/root tests
and the callback CPU-work budgets now pass.

The triode root-jump and independent derivative tests now pass. A further tone-stack
CPU overrun came from repeatedly designing identical coefficients for every
channel during smoothing. The design is now computed once per frame and copied
while signal/defect state remains independent. The 12-channel trajectory matches
independent mono instances bit-for-bit through automation, reset, and value-set
changes. All representative small-buffer CPU budgets passed in the focused run.

The owned decay compatibility constructor also has a separate allocation budget.
Its first implementation cloned the retained output, requesting 11,520,000 bytes
for a 480k-sample input instead of the 7,680,000-byte integral/output pair. The
new regression failed before replacing that clone with an ownership transfer.
Borrowed `compute` retains its output; the owning compatibility method transfers
it as before, without a redundant full-record copy.

## Post-fix benchmark evidence

Criterion `--quick`, native aarch64 release/LTO; numbers are the middle estimates
printed by Criterion. The host was shared with builds and other work. The
original audit used a separate manual timing harness, so these are diagnostic
observations, not a controlled historical speedup claim or a latency guarantee.

| Operation | Measured time |
|---|---:|
| Welch into reusable outputs, 48k samples / FFT4096 | 109.92 µs |
| Prepared resampler, 1 output / 48k input | 13.345 µs |
| Resampler including setup, 1 output | 525.27 µs |
| Prepared resampler, 256 outputs | 34.308 µs |
| Prepared resampler, 48k outputs | 3.9927 ms |
| STFT identity, N1024/hop128, block256 | 6.0933 µs |
| Median separation, 1025 bins, kernels 5/15/31 | 16.676 / 56.057 / 115.62 µs |
| Asymmetric f64 FIR, taps32/block64, block / sample loop | 345.69 / 335.42 ns |
| Asymmetric f64 FIR, taps128/block64, block / sample loop | 1.1345 / 1.1450 µs |
| Asymmetric f64 FIR, taps512/block64, block / sample loop | 7.2287 / 6.7613 µs |

The asymmetrical block path now uses the same SIMD convolution as the sample
path. Both APIs include the benchmark's buffer copy; block processing also owns
the denormal guard. No exact parity claim is made at every size.

Line coverage gates passed: convex hull 93.89% (required 90), DSP 86.10%
(required 82), IIR/FIR 87.81% (required 80), analog 82.21% (required 78),
RIR 97.11% (required 94), and QA 95.22% (required 90). The verifier executable
was exercised by the record gate; its `main` is not exercised by the coverage
test harness (0/10 executable lines).

The QA coverage rerun reproduced the same 95.22% line summary and passed its
90% gate, but LLVM still emitted `22 functions have mismatched data`. This is
a coverage-tool diagnostic, not a test failure; the reported percentages carry
that limitation. Independent release tests and the separate 13-record execution
gate both passed. No branch-coverage, formal proof, or mutation-score claim is made.
