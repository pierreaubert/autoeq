/// Cross-mode comparison tolerances — calibrated from empirical results.
///
/// Findings from tightening (3 room sizes, 4 modes):
///
/// **Score ratios**: Before Phase 3, `optimize_stereo_2_0` always called
///   `eq::optimize_channel_eq` regardless of `processing_mode`, so iir / fir /
///   hybrid / mixed_phase produced near-identical results. Phase 3 routes
///   each channel through `process_single_speaker`, which honours
///   `processing_mode` — so modes now genuinely diverge on bass-heavy
///   scenarios. Observed ratios: up to 1.7× on small rooms with a strong
///   sub-100 Hz mode. Limit loosened to 2.0× to reflect this.
///
/// **FR peak diff**: Large (11-20 dB) at specific room mode frequencies.
///   IIR targets narrow modes precisely; FIR spreads correction broadly.
///   Worse in large rooms (more/denser modes). This is fundamental, not a bug.
///   Peak diff is reported for diagnostics but NOT asserted — it's not meaningful.
///
/// **FR RMS diff**: The meaningful metric. Small rooms ~2.5 dB, large rooms
///   ~4.4 dB, edge-case stereo 2.0 after Phase 3 can reach ~5.3 dB because
///   IIR and FIR handle the same modal peak with different filter shapes.
///   Current seeded medium-room cases can reach a little over 8 dB after
///   mixed-phase and hybrid modes choose different modal tradeoffs.
///
/// **Improvement**: All modes achieve 34-58% per-channel, 45-55% combined.
pub(super) const CROSS_MODE_SCORE_RATIO_LIMIT: f64 = 2.0; // post-Phase-3 calibration

pub(super) const MAX_CHANNEL_REGRESSION: f64 = 1.02; // max 2% regression per channel

/// RMS dB difference — the meaningful broadband agreement metric.
/// 9 dB allows for stereo 2.0 after Phase 3, where processing_mode now
/// reaches the per-channel pipeline and legitimately diverges mode by mode.
pub(super) const CROSS_MODE_FR_RMS_DIFF_DB: f64 = 9.0;

/// Peak diff reported but not a hard failure — logged for diagnostics
pub(super) const CROSS_MODE_FR_PEAK_WARN_DB: f64 = 10.0;
