//! Objective-function evaluation for AutoEQ, independent of optimizer backends.
//!
//! Extracted from `autoeq-optim` (refactor-20261025 Phase 3c) so
//! prepared objective evaluation, loss computations, and evaluation
//! budgets can be reused without compiling any optimizer backend.
//! `autoeq-optim` re-exports every module here, so existing
//! `autoeq_optim::` paths keep resolving.

pub use autoeq_core as core;
pub use autoeq_core::iir;
pub use autoeq_core::{AutoeqError, Curve, PeqModel, Result};
pub use autoeq_measurements as measurements;

pub mod error {
    pub use autoeq_core::error::*;
}
pub mod read {
    pub use autoeq_measurements::read::*;
}
pub mod cea2034 {
    pub use autoeq_measurements::cea2034::*;
}
pub mod param_utils {
    pub use autoeq_core::param_utils::*;
}
pub mod x2peq {
    pub use autoeq_core::x2peq::*;
}
pub mod roomeq {
    pub use crate::roomeq_types::{
        AudibilityDeadbandConfig, ModeProximityEvidence, MultiMeasurementStrategy,
    };
    pub mod phase_utils {
        pub use autoeq_core::phase_utils::*;
    }
}

pub mod constraints;
pub mod loss;
pub mod optim;
pub mod penalty_mode;
pub mod roomeq_types;
pub mod smoothness_penalty_config;

pub use loss::{CrossoverType, HeadphoneLossData, LossType, SpeakerLossData};
pub use optim::{MultiObjectiveData, ObjectiveData, ObjectiveDataBuilder};
pub use penalty_mode::PenaltyMode;
pub use smoothness_penalty_config::SmoothnessPenaltyConfig;
