/// Smoothness regularizer on the cascaded biquad magnitude response.
///
/// Penalizes curvature (in dB/decade^2) of `peq_spl` on the log-frequency
/// grid, suppressing wiggle filter pairs that opposite-cancel. Linear
/// tilts and broad shelves are free; narrow PEQ peaks pay curvature;
/// opposing peak/dip pairs pay repeatedly across direction reversals.
#[derive(Debug, Clone)]
pub struct SmoothnessPenaltyConfig {
    /// Penalty weight in loss units per (dB/decade^2)^exponent. 0.0 disables.
    pub tv2_weight: f64,
    /// Optional Schroeder cutoff in Hz. Below this, weight is scaled by
    /// `modal_weight_scale` so high-Q modal cuts are less penalized.
    pub schroeder_hz: Option<f64>,
    /// Multiplier applied below `schroeder_hz`.
    pub modal_weight_scale: f64,
    /// L_p exponent for per-bin penalty. 1.0 = TV^2 style sparsifier,
    /// 2.0 = L2 smoothing.
    pub exponent: f64,
}

impl Default for SmoothnessPenaltyConfig {
    fn default() -> Self {
        Self {
            tv2_weight: 0.0,
            schroeder_hz: None,
            modal_weight_scale: 0.1,
            exponent: 1.0,
        }
    }
}
