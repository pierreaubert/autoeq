# autoeq-optim-types architecture

- `evidence`: Pareto dispatch and input-normalization evidence types
  with their validation logic. Produced by `autoeq-optim` backends,
  consumed by `roomeq-engine` and `roomeq-model` report assembly.
- `reference_registry`: approved independent-reference entries and
  verified-evidence checks used by perceptual promotion gates in
  `autoeq-optim`, `roomeq-quality`, and `roomeq-qa`.

Dependencies: `serde` and `schemars` only. This crate must stay
below both the optimizer and the RoomEQ model in the dependency
graph; it never imports workspace crates.
