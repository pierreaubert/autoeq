pub(super) fn default_flatness_erb_weight() -> f64 {
    1.0
}

pub(super) fn default_temporal_masking_enabled() -> bool {
    true
}

pub(super) fn default_temporal_masking_weight() -> f64 {
    0.15
}

pub(super) fn default_ir_temporal_masking_enabled() -> bool {
    true
}

pub(super) fn default_ir_temporal_masking_weight() -> f64 {
    0.05
}

pub(super) fn default_pre_mask_ms() -> f64 {
    3.0
}

pub(super) fn default_post_mask_ms() -> f64 {
    120.0
}

pub(super) fn default_pre_ringing_weight() -> f64 {
    2.0
}

pub(super) fn default_post_ringing_weight() -> f64 {
    1.0
}

pub(super) fn default_ir_audibility_threshold_db() -> f64 {
    -45.0
}
