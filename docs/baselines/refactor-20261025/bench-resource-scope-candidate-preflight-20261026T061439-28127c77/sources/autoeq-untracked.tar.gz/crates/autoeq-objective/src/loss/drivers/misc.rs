use num_complex::Complex64;
use std::f64::consts::PI;

/// Helper to compute complex response of a biquad filter
pub(super) fn biquad_complex_response(biquad: &crate::iir::Biquad, f: f64) -> Complex64 {
    let (a1, a2, b0, b1, b2) = biquad.constants();
    let omega = 2.0 * PI * f / biquad.srate;
    // z^-1 = e^(-j*omega) = cos(-omega) + j*sin(-omega)
    let z_inv = Complex64::from_polar(1.0, -omega);
    let z_inv2 = z_inv * z_inv;

    let num = b0 + b1 * z_inv + b2 * z_inv2;
    let den = 1.0 + a1 * z_inv + a2 * z_inv2;

    num / den
}

pub(super) fn fir_complex_response(coeffs: &[f64], freq: f64, sample_rate: f64) -> Complex64 {
    let w = 2.0 * PI * freq / sample_rate;
    coeffs
        .iter()
        .enumerate()
        .fold(Complex64::new(0.0, 0.0), |acc, (n, &coeff)| {
            acc + Complex64::from_polar(coeff, -w * n as f64)
        })
}
