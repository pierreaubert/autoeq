use super::consts::CROSS_MODE_FR_PEAK_WARN_DB;
use super::consts::CROSS_MODE_FR_RMS_DIFF_DB;
use super::consts::CROSS_MODE_SCORE_RATIO_LIMIT;
use super::consts::MAX_CHANNEL_REGRESSION;
use super::misc::allow_empty_main_eq;
use super::misc::crate_root;
use super::misc::curve_diff_stats;
use super::misc::workspace_root;
use super::types::ModeConfig;
use super::types::all_mode_configs;
use roomeq_model::CorrectionDecision;
use roomeq_model::{ProcessingMode, RoomConfig};
use roomeq_workflow::optimize_room;
use serial_test::serial;
use std::path::Path;

const QA_SEED_OFFSETS: [u64; 5] = [0, 17, 41, 73, 109];

fn assert_integration_registry_contract() {
    static CHECKED: std::sync::OnceLock<()> = std::sync::OnceLock::new();
    CHECKED.get_or_init(|| {
        let registry = roomeq_qa::registry::load_registry().expect("load RoomEQ QA registry");
        let suite = registry
            .suite_for_runner("integration")
            .expect("integration suite must be registered");
        for claim in ["fem_end_to_end", "multi_seed"] {
            assert!(
                suite.claims.iter().any(|registered| registered == claim),
                "integration registry suite missing claim '{claim}'"
            );
        }
    });
}

fn integration_expectation(scenario_name: &str) -> (f64, bool) {
    let registry_scenario = match scenario_name {
        "medium_multi_sub_multi_seat" => "medium_multi_sub_4",
        other => other,
    };
    let expect = roomeq_qa::registry::load_registry()
        .expect("load RoomEQ QA registry")
        .families
        .into_iter()
        .find(|family| family.solver == "fem" && family.scenario == registry_scenario)
        .unwrap_or_else(|| panic!("missing FEM registry family for '{scenario_name}'"))
        .expect;
    (expect.improvement_min_pct, expect.allow_safe_revert)
}

fn integration_improvement_floor(scenario_name: &str, registry_min_pct: f64) -> f64 {
    let integration_floor = match scenario_name {
        "large_multi_sub_4" => 1.0,
        "large_stereo_2_0" => 7.0,
        "medium_multi_sub_4" => 7.5,
        "medium_multi_sub_multi_seat" => 9.0,
        "small_multi_sub_2" | "small_stereo_2_2_mso" => 8.0,
        _ => registry_min_pct,
    };
    registry_min_pct.min(integration_floor)
}

fn multimode_safe_revert(scenario_name: &str, mode_name: &str) -> bool {
    matches!(
        (scenario_name, mode_name),
        ("small_stereo_2_0", "fir" | "hybrid") | ("medium_stereo_2_0", "hybrid")
    )
}

fn optimize_median_seed(
    config: &RoomConfig,
    output_dir: Option<&Path>,
    context: &str,
) -> roomeq_engine::room_result::RoomOptimizationResult {
    assert_integration_registry_contract();

    let base_seed = config.optimizer.seed.unwrap_or(42);
    let mut results = Vec::with_capacity(QA_SEED_OFFSETS.len());
    for offset in QA_SEED_OFFSETS {
        let seed = base_seed.wrapping_add(offset);
        let mut seeded_config = config.clone();
        seeded_config.optimizer.seed = Some(seed);
        let seed_output_dir = output_dir.map(|root| root.join(format!("seed-{seed}")));
        if let Some(directory) = &seed_output_dir {
            std::fs::create_dir_all(directory).unwrap_or_else(|error| {
                panic!("Failed to create {context} seed output directory: {error}")
            });
        }
        let result = optimize_room(&seeded_config, 48_000.0, None, seed_output_dir.as_deref())
            .unwrap_or_else(|error| panic!("Optimization failed {context} seed={seed}: {error}"));
        assert!(
            result.combined_post_score.is_finite(),
            "{context} seed={seed} produced a non-finite post score"
        );
        results.push((seed, result));
    }
    results.sort_by(|left, right| {
        left.1
            .combined_post_score
            .total_cmp(&right.1.combined_post_score)
    });
    let min_score = results
        .first()
        .map(|entry| entry.1.combined_post_score)
        .unwrap_or_default();
    let max_score = results
        .last()
        .map(|entry| entry.1.combined_post_score)
        .unwrap_or_default();
    let details = results
        .iter()
        .map(|(seed, result)| format!("{seed}:{:.6}", result.combined_post_score))
        .collect::<Vec<_>>()
        .join(",");
    let selected_index = results.len() / 2;
    println!(
        "{context}: selected median seed {}, min={min_score:.6}, max={max_score:.6}, spread={:.6}, scores=[{details}]",
        results[selected_index].0,
        max_score - min_score
    );
    results.swap_remove(selected_index).1
}

/// Run roomeq optimization on a generated FEM scenario and verify improvement
fn run_roomeq_on_generated(scenario_name: &str) {
    let config_path = crate_root()
        .join("data_tests/roomeq/generate/fem")
        .join(scenario_name)
        .join("config.json");

    let config_json = std::fs::read_to_string(&config_path)
        .unwrap_or_else(|e| panic!("Failed to read config for {scenario_name}: {e}"));
    let mut config: RoomConfig = serde_json::from_str(&config_json)
        .unwrap_or_else(|e| panic!("Failed to parse config for {scenario_name}: {e}"));

    // Resolve CSV paths relative to the config file's directory
    if let Some(config_dir) = config_path.parent() {
        config.resolve_paths(config_dir);
    }

    // Reduce iterations for faster tests
    config.optimizer.max_iter = 2000;
    // Use fixed seed for reproducible results
    config.optimizer.seed = Some(42);

    let result = optimize_median_seed(&config, None, scenario_name);
    let (registry_min_pct, allow_safe_revert) = integration_expectation(scenario_name);
    let improvement_min_pct = integration_improvement_floor(scenario_name, registry_min_pct);
    let safety_reverted = result
        .metadata
        .correction_acceptance
        .as_ref()
        .is_some_and(|report| {
            matches!(
                report.decision,
                CorrectionDecision::RevertedStage | CorrectionDecision::IdentityFallback
            )
        });
    let allowed_safety_revert = safety_reverted && allow_safe_revert;

    // Verify optimization improved the response
    assert!(
        allowed_safety_revert || result.combined_post_score < result.combined_pre_score,
        "{scenario_name}: optimization did not improve score: pre={:.4}, post={:.4}",
        result.combined_pre_score,
        result.combined_post_score
    );

    // Verify at least 10% improvement
    let improvement = 1.0 - result.combined_post_score / result.combined_pre_score;
    let min_improvement = improvement_min_pct / 100.0;
    assert!(
        allowed_safety_revert || improvement > min_improvement,
        "{scenario_name}: improvement {:.1}% is less than {:.1}% (pre={:.4}, post={:.4})",
        improvement * 100.0,
        min_improvement * 100.0,
        result.combined_pre_score,
        result.combined_post_score
    );

    // Verify all channels have EQ results.
    // Sub/LFE channels may legitimately have empty biquads when the "do no harm"
    // guard in the 2.1 workflow discards Post-EQ that would degrade the response.
    let sub_names = ["LFE", "lfe", "sub"];
    for (channel_name, channel_result) in &result.channel_results {
        let is_sub = sub_names
            .iter()
            .any(|s| channel_name.eq_ignore_ascii_case(s))
            || channel_name.to_lowercase().starts_with("sub");
        if !allowed_safety_revert && !is_sub && !allow_empty_main_eq(scenario_name) {
            assert!(
                !channel_result.biquads.is_empty(),
                "{scenario_name}: channel '{channel_name}' has no biquad filters"
            );
        }
        // Allow up to 10% per-channel regression — the optimizer minimizes the
        // combined score across all channels, so individual channels may trade
        // a small regression for a better overall result.
        if !is_sub {
            let max_allowed = channel_result.pre_score * 1.10;
            assert!(
                channel_result.post_score < max_allowed,
                "{scenario_name}: channel '{channel_name}' regressed too much: pre={:.4}, post={:.4} (max={:.4})",
                channel_result.pre_score,
                channel_result.post_score,
                max_allowed
            );
        }
    }

    // Verify DSP chains were generated for channels that should receive EQ.
    // Sub/LFE channels may legitimately have no plugins when the "do no harm"
    // guard rejects EQ that would make the response worse.
    for (channel_name, chain) in &result.channels {
        let is_sub = sub_names
            .iter()
            .any(|s| channel_name.eq_ignore_ascii_case(s))
            || channel_name.to_lowercase().starts_with("sub");
        if allowed_safety_revert || is_sub || allow_empty_main_eq(scenario_name) {
            continue;
        }
        assert!(
            !chain.plugins.is_empty(),
            "{scenario_name}: channel '{channel_name}' has no plugins in DSP chain"
        );
    }
}

#[test]
#[serial]
fn test_roomeq_small_stereo_2_0() {
    run_roomeq_on_generated("small_stereo_2_0");
}

#[test]
#[serial]
#[ignore = "full FEM convergence matrix; run the documented --ignored command"]
fn test_roomeq_medium_stereo_2_0() {
    run_roomeq_on_generated("medium_stereo_2_0");
}

#[test]
#[serial]
#[ignore = "full FEM convergence matrix; run the documented --ignored command"]
fn test_roomeq_large_stereo_2_0() {
    run_roomeq_on_generated("large_stereo_2_0");
}

#[test]
#[serial]
#[ignore = "full FEM convergence matrix; run the documented --ignored command"]
fn test_roomeq_small_stereo_2_1() {
    run_roomeq_on_generated("small_stereo_2_1");
}

#[test]
#[serial]
#[ignore = "full FEM convergence matrix; run the documented --ignored command"]
fn test_roomeq_medium_stereo_2_1() {
    run_roomeq_on_generated("medium_stereo_2_1");
}

#[test]
#[serial]
#[ignore = "full FEM convergence matrix; run the documented --ignored command"]
fn test_roomeq_large_stereo_2_1() {
    run_roomeq_on_generated("large_stereo_2_1");
}

#[test]
#[serial]
#[ignore = "full FEM convergence matrix; run the documented --ignored command"]
fn test_roomeq_medium_multi_seat() {
    run_roomeq_on_generated("medium_multi_seat");
}

#[test]
#[serial]
#[ignore = "full FEM convergence matrix; run the documented --ignored command"]
fn test_roomeq_small_multi_sub_2() {
    run_roomeq_on_generated("small_stereo_2_2_mso");
}

#[test]
#[serial]
#[ignore = "full FEM convergence matrix; run the documented --ignored command"]
fn test_roomeq_medium_multi_sub_4() {
    run_roomeq_on_generated("medium_multi_sub_4");
}

#[test]
#[serial]
#[ignore = "full FEM convergence matrix; run the documented --ignored command"]
fn test_roomeq_large_multi_sub_4() {
    run_roomeq_on_generated("large_multi_sub_4");
}

#[test]
#[serial]
#[ignore = "full FEM convergence matrix; run the documented --ignored command"]
fn test_roomeq_large_multi_seat_2_1() {
    run_roomeq_on_generated("large_multi_seat_2_1");
}

#[test]
#[serial]
#[ignore = "full FEM convergence matrix; run the documented --ignored command"]
fn test_roomeq_medium_multi_sub_multi_seat() {
    run_roomeq_on_generated("medium_multi_sub_multi_seat");
}

/// Run roomeq optimization on a FEM scenario with a specific processing mode
fn run_roomeq_with_mode(
    scenario_name: &str,
    mode_config: &ModeConfig,
    output_dir: &Path,
) -> roomeq_engine::room_result::RoomOptimizationResult {
    let config_path = crate_root()
        .join("data_tests/roomeq/generate/fem")
        .join(scenario_name)
        .join("config.json");

    let config_json = std::fs::read_to_string(&config_path)
        .unwrap_or_else(|e| panic!("Failed to read config for {scenario_name}: {e}"));
    let mut config: RoomConfig = serde_json::from_str(&config_json)
        .unwrap_or_else(|e| panic!("Failed to parse config for {scenario_name}: {e}"));

    if let Some(config_dir) = config_path.parent() {
        config.resolve_paths(config_dir);
    }

    // Override processing mode
    config.optimizer.processing_mode = mode_config.processing_mode.clone();
    config.optimizer.fir = mode_config.fir.clone();
    config.optimizer.mixed_phase = mode_config.mixed_phase.clone();

    // Enable channel matching correction
    config.optimizer.channel_matching = Some(roomeq_model::ChannelMatchingConfig::default());

    // Reduced iterations for speed, fixed seed for reproducibility
    config.optimizer.max_iter = 2000;
    config.optimizer.refine = false;
    config.optimizer.seed = Some(42);

    // FIR/Hybrid need max_freq capped for reasonable tap counts
    if matches!(
        mode_config.processing_mode,
        ProcessingMode::PhaseLinear | ProcessingMode::Hybrid
    ) {
        config.optimizer.max_freq = config.optimizer.max_freq.min(1500.0);
    }

    optimize_median_seed(
        &config,
        Some(output_dir),
        &format!("{scenario_name} mode={}", mode_config.name),
    )
}

/// Run all 4 modes on a scenario, assert per-mode quality and cross-mode consistency
fn run_multimode_comparison(scenario_name: &str) {
    let output_base = workspace_root()
        .join("data_generated/roomeq_comparison")
        .join(scenario_name);

    let modes = all_mode_configs();
    let mut results: Vec<(&str, roomeq_engine::room_result::RoomOptimizationResult)> = Vec::new();
    let mut failures: Vec<String> = Vec::new();
    let (registry_min_pct, allow_safe_revert) = integration_expectation(scenario_name);
    let improvement_min_pct = integration_improvement_floor(scenario_name, registry_min_pct);

    println!("\n=== {scenario_name}: Multi-mode comparison ===");

    for mode in &modes {
        let mode_dir = output_base.join(mode.name);
        std::fs::create_dir_all(&mode_dir).unwrap();

        let result = run_roomeq_with_mode(scenario_name, mode, &mode_dir);

        let improvement = 1.0 - result.combined_post_score / result.combined_pre_score;
        let safety_reverted =
            result
                .metadata
                .correction_acceptance
                .as_ref()
                .is_some_and(|report| {
                    matches!(
                        report.decision,
                        CorrectionDecision::RevertedStage | CorrectionDecision::IdentityFallback
                    )
                });
        let allowed_safety_revert = safety_reverted
            && (allow_safe_revert || multimode_safe_revert(scenario_name, mode.name));
        println!(
            "  {:12} pre={:.4}  post={:.4}  improv={:.1}%  filters={}",
            mode.name,
            result.combined_pre_score,
            result.combined_post_score,
            improvement * 100.0,
            result
                .channel_results
                .values()
                .map(|ch| ch.biquads.len())
                .sum::<usize>(),
        );

        // Per-channel detail
        for (ch_name, ch_result) in &result.channel_results {
            let ch_improv = 1.0 - ch_result.post_score / ch_result.pre_score;
            let fir_len = ch_result.fir_coeffs.as_ref().map_or(0, |c| c.len());
            println!(
                "    {:8} pre={:.4}  post={:.4}  improv={:.1}%  biquads={}  fir_taps={}",
                ch_name,
                ch_result.pre_score,
                ch_result.post_score,
                ch_improv * 100.0,
                ch_result.biquads.len(),
                fir_len,
            );
        }

        // Check: optimization must improve
        if !allowed_safety_revert && result.combined_post_score >= result.combined_pre_score {
            failures.push(format!(
                "{}/{}: NO improvement (pre={:.4}, post={:.4})",
                scenario_name, mode.name, result.combined_pre_score, result.combined_post_score,
            ));
        }

        // Check: minimum improvement threshold
        let min_improvement = improvement_min_pct / 100.0;
        if !allowed_safety_revert && improvement < min_improvement {
            failures.push(format!(
                "{}/{}: improvement {:.1}% < {:.0}% minimum",
                scenario_name,
                mode.name,
                improvement * 100.0,
                improvement_min_pct,
            ));
        }

        // Check: no channel regression beyond threshold
        let sub_names = ["LFE", "lfe", "sub"];
        for (ch_name, ch_result) in &result.channel_results {
            if allowed_safety_revert {
                continue;
            }
            let is_sub = sub_names.iter().any(|s| ch_name.eq_ignore_ascii_case(s))
                || ch_name.to_lowercase().starts_with("sub");
            if !is_sub {
                let ratio = ch_result.post_score / ch_result.pre_score;
                if ratio > MAX_CHANNEL_REGRESSION {
                    failures.push(format!(
                        "{}/{}/{}: channel regressed {:.1}% (pre={:.4}, post={:.4}, limit={:.0}%)",
                        scenario_name,
                        mode.name,
                        ch_name,
                        (ratio - 1.0) * 100.0,
                        ch_result.pre_score,
                        ch_result.post_score,
                        (MAX_CHANNEL_REGRESSION - 1.0) * 100.0,
                    ));
                }
            }
        }

        // Save output JSON
        let dsp_output = result.to_dsp_chain_output();
        let json_path = mode_dir.join(format!("{}.json", mode.name));
        let json = serde_json::to_string_pretty(&dsp_output).unwrap();
        std::fs::write(&json_path, json).unwrap();

        results.push((mode.name, result));
    }

    // Cross-mode consistency: score ratio between any pair
    println!("\n  Cross-mode score ratios:");
    for i in 0..results.len() {
        for j in (i + 1)..results.len() {
            let (name_a, res_a) = &results[i];
            let (name_b, res_b) = &results[j];

            let score_a = res_a.combined_post_score;
            let score_b = res_b.combined_post_score;
            let ratio = if score_a > score_b {
                score_a / score_b
            } else {
                score_b / score_a
            };

            let status = if ratio < CROSS_MODE_SCORE_RATIO_LIMIT {
                "OK"
            } else {
                "FAIL"
            };
            println!(
                "    {name_a:12} vs {name_b:12}: ratio={ratio:.3}  ({name_a}={score_a:.4}, {name_b}={score_b:.4})  [{status}]",
            );

            if ratio >= CROSS_MODE_SCORE_RATIO_LIMIT {
                failures.push(format!(
                    "{scenario_name}: score ratio {name_a}/{name_b} = {ratio:.3} >= {CROSS_MODE_SCORE_RATIO_LIMIT} \
                     ({name_a}={score_a:.4}, {name_b}={score_b:.4})",
                ));
            }
        }
    }

    // Cross-mode consistency: final curve dB difference in passband
    println!("\n  Cross-mode FR differences (in optimization range):");
    let channel_names: Vec<String> = results[0].1.channel_results.keys().cloned().collect();
    for ch_name in &channel_names {
        for i in 0..results.len() {
            for j in (i + 1)..results.len() {
                let (name_a, res_a) = &results[i];
                let (name_b, res_b) = &results[j];

                let curve_a = &res_a.channel_results[ch_name].final_curve;
                let curve_b = &res_b.channel_results[ch_name].final_curve;

                // Use the optimization frequency range from the config
                let freq_lo = 20.0_f64.max(curve_a.freq[0]).max(curve_b.freq[0]);
                let freq_hi = 500.0_f64
                    .min(curve_a.freq[curve_a.freq.len() - 1])
                    .min(curve_b.freq[curve_b.freq.len() - 1]);

                let (rms_diff, max_diff, freq_at_max) =
                    curve_diff_stats(curve_a, curve_b, freq_lo, freq_hi);

                let peak_tag = if max_diff < CROSS_MODE_FR_PEAK_WARN_DB {
                    "OK"
                } else {
                    "WARN"
                };
                let rms_status = if rms_diff < CROSS_MODE_FR_RMS_DIFF_DB {
                    "OK"
                } else {
                    "FAIL"
                };

                println!(
                    "    {ch_name:8} {name_a:12} vs {name_b:12}: peak={max_diff:.1}dB @{freq_at_max:.0}Hz [{peak_tag}]  rms={rms_diff:.2}dB [{rms_status}]",
                );

                // Peak diff is diagnostic only — room modes cause fundamental disagreement
                // RMS is the hard check for broadband agreement
                if rms_diff >= CROSS_MODE_FR_RMS_DIFF_DB {
                    failures.push(format!(
                        "{scenario_name}/{ch_name}: FR rms diff {name_a} vs {name_b} = {rms_diff:.2}dB >= {CROSS_MODE_FR_RMS_DIFF_DB}dB",
                    ));
                }
            }
        }
    }

    // Inter-channel deviation from metadata
    println!("\n  Inter-channel deviation (ICD) per mode:");
    for (mode_name, result) in &results {
        if let Some(icd) = &result.metadata.inter_channel_deviation {
            println!(
                "    {:12} midrange_rms={:.2}dB  peak={:.1}dB @{:.0}Hz  passband_rms={:.2}dB",
                mode_name,
                icd.midrange_rms_db,
                icd.midrange_peak_db,
                icd.midrange_peak_freq,
                icd.passband_rms_db,
            );
        } else {
            println!("    {:12} (no ICD data)", mode_name);
        }
    }

    // Report all failures at once for full visibility
    if !failures.is_empty() {
        println!("\n  FAILURES ({}):", failures.len());
        for f in &failures {
            println!("    - {f}");
        }
        panic!(
            "{scenario_name}: {} assertion(s) failed:\n{}",
            failures.len(),
            failures
                .iter()
                .map(|f| format!("  - {f}"))
                .collect::<Vec<_>>()
                .join("\n"),
        );
    }

    println!("  {scenario_name}: ALL CHECKS PASSED");
}

#[test]
#[serial]
#[ignore = "full FEM multimode matrix; run the documented --ignored command"]
fn test_multimode_comparison_small_stereo_2_0() {
    run_multimode_comparison("small_stereo_2_0");
}

#[test]
#[serial]
#[ignore = "full FEM multimode matrix; run the documented --ignored command"]
fn test_multimode_comparison_medium_stereo_2_0() {
    run_multimode_comparison("medium_stereo_2_0");
}

#[test]
#[serial]
#[ignore = "full FEM multimode matrix; run the documented --ignored command"]
fn test_multimode_comparison_large_stereo_2_0() {
    run_multimode_comparison("large_stereo_2_0");
}
