import unittest
from scripts.run_roomeq_coverage import PACKAGES, included, inventory, responsibility_lines


class CoverageOwnershipTests(unittest.TestCase):
    def test_scope_follows_moved_production_sources(self):
        for path in ('roomeq-dsp/src/physical_routing.rs',
                     'autoeq-optim-types/src/reference_registry.rs',
                     'autoeq-optim-types/src/evidence.rs',
                     'roomeq-workflow/src/room_optimization.rs'):
            self.assertTrue(included('/workspace/crates/' + path), path)

    def test_fixtures_and_unrelated_contracts_are_excluded(self):
        for path in ('roomeq-workflow/tests/fixture.rs', 'roomeq-qa/src/registry.rs',
                     'autoeq-optim-types/src/config.rs', 'autoeq-optim-types/src/loss.rs',
                     'roomeq-cli/src/roomeq.rs'):
            self.assertFalse(included('/workspace/crates/' + path), path)

    def test_missing_owner_fails_closed(self):
        with self.assertRaisesRegex(ValueError, 'no source inventory'):
            inventory({'data': [{'files': []}]})

    def test_unexpected_report_file_fails_closed(self):
        with self.assertRaisesRegex(ValueError, 'out-of-scope'):
            inventory({'data': [{'files': [{'filename': '/workspace/crates/roomeq-qa/src/lib.rs'}]}]})

    def test_each_owner_has_line_mapping(self):
        files = [{'filename': '/workspace/crates/' + package + '/src/' +
                  ('evidence.rs' if package == 'autoeq-optim-types' else 'lib.rs'),
                  'summary': {'lines': {'count': 10, 'covered': 9, 'percent': 90}}}
                 for package in PACKAGES]
        result = inventory({'data': [{'files': files}]})
        self.assertEqual(len(result['files']), len(PACKAGES))

    def test_supplemental_helper_cannot_inflate_original_coverage(self):
        source = '// original\nfn old() {}\n/// One local-Q projection at a decoded filter center.\nfn helper() {}\n'
        lcov = 'SF:/workspace/crates/autoeq-optim-types/src/evidence.rs\nDA:2,0\nDA:4,3\nend_of_record\n'
        result = responsibility_lines(lcov, source)
        self.assertEqual(result, {'count': 1, 'covered': 0, 'percent': 0,
                                  'supplemental_count': 1, 'supplemental_covered': 1})

    def test_missing_supplemental_boundary_fails_closed(self):
        with self.assertRaisesRegex(ValueError, 'boundary'):
            responsibility_lines('', 'changed source')


if __name__ == '__main__':
    unittest.main()
