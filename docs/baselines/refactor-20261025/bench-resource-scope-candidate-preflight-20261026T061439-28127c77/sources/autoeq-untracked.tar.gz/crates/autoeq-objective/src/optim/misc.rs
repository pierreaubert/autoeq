use crate::Curve;
use ndarray::Array1;

/// Interpolate a frequency-dependent envelope in log-frequency space.
pub fn interpolate_boost_envelope(envelope: &[(f64, f64)], freq_hz: f64) -> f64 {
    if envelope.is_empty() {
        return f64::INFINITY;
    }
    if freq_hz <= envelope[0].0 {
        return envelope[0].1;
    }
    let last = envelope.len() - 1;
    if freq_hz >= envelope[last].0 {
        return envelope[last].1;
    }
    for i in 0..last {
        let (f0, db0) = envelope[i];
        let (f1, db1) = envelope[i + 1];
        if freq_hz >= f0 && freq_hz <= f1 {
            let t = (freq_hz.ln() - f0.ln()) / (f1.ln() - f0.ln());
            return db0 + t * (db1 - db0);
        }
    }
    envelope[last].1
}

pub fn maybe_smooth_error(
    freqs: &Array1<f64>,
    error: Array1<f64>,
    smooth: bool,
    smooth_n: usize,
) -> Array1<f64> {
    if !smooth {
        return error;
    }
    let curve = Curve {
        freq: freqs.clone(),
        spl: error,
        phase: None,
        ..Default::default()
    };
    crate::read::smooth_one_over_n_octave(&curve, smooth_n).spl
}

pub fn apply_audibility_deadband(
    freqs: &Array1<f64>,
    error: &Array1<f64>,
    min_freq: f64,
    max_freq: f64,
    config: Option<&crate::roomeq::AudibilityDeadbandConfig>,
) -> Array1<f64> {
    let Some(config) = config.filter(|cfg| cfg.enabled) else {
        return error.clone();
    };

    let mut out = error.clone();
    for (idx, value) in out.iter_mut().enumerate() {
        let Some(&freq) = freqs.get(idx) else {
            continue;
        };
        if freq < min_freq || freq > max_freq {
            continue;
        }
        if config.disable_below_schroeder && freq < config.schroeder_hz {
            continue;
        }
        let threshold = audibility_deadband_threshold(freq, config);
        let magnitude = value.abs();
        if magnitude <= threshold {
            *value = 0.0;
        } else {
            *value = value.signum() * (magnitude - threshold);
        }
    }
    out
}

pub fn audibility_deadband_threshold(
    freq: f64,
    config: &crate::roomeq::AudibilityDeadbandConfig,
) -> f64 {
    if freq <= config.bass_mid_hz {
        config.bass_db
    } else if freq >= config.mid_treble_hz {
        config.treble_db
    } else {
        let t = (freq.ln() - config.bass_mid_hz.ln())
            / (config.mid_treble_hz.ln() - config.bass_mid_hz.ln());
        config.mid_db + t * (config.treble_db - config.mid_db)
    }
}

#[cfg(test)]
mod audibility_deadband_tests {

    use crate::optim::misc::apply_audibility_deadband;
    use crate::roomeq::AudibilityDeadbandConfig;
    use ndarray::array;

    #[test]
    fn deadband_zeroes_inaudible_midrange_residuals() {
        let freqs = array![100.0, 1_000.0, 4_000.0];
        let error = array![0.2, 0.5, -1.5];
        let cfg = AudibilityDeadbandConfig {
            bass_db: 0.25,
            mid_db: 0.75,
            treble_db: 1.0,
            disable_below_schroeder: true,
            schroeder_hz: 250.0,
            ..Default::default()
        };

        let out = apply_audibility_deadband(&freqs, &error, 20.0, 20_000.0, Some(&cfg));

        assert_eq!(out[0], 0.2, "below Schroeder is preserved by default");
        assert_eq!(out[1], 0.0, "midrange residual below JND is ignored");
        assert!(out[2] < 0.0 && out[2].abs() < error[2].abs());
    }
}

/// Weighted Euclidean compromise distance from the ideal point.
///
/// Each objective is normalised by the ideal-nadir span before the weighted
/// sum of squares is computed.  This is shared between the NSGA and Bayesian
/// Pareto selection code.
pub fn compromise_distance(
    objectives: &[f64],
    ideal: &[f64],
    nadir: &[f64],
    weights: &[f64],
) -> f64 {
    objectives
        .iter()
        .enumerate()
        .map(|(i, &v)| {
            let span = nadir[i] - ideal[i];
            let norm = if span > 0.0 && span.is_finite() {
                (v - ideal[i]) / span
            } else {
                0.0
            };
            weights[i] * norm * norm
        })
        .sum::<f64>()
        .sqrt()
}

#[cfg(test)]
mod tests {
    use super::*;
    use ndarray::Array1;

    #[test]
    fn interpolate_boost_envelope_empty() {
        assert_eq!(interpolate_boost_envelope(&[], 100.0), f64::INFINITY);
    }

    #[test]
    fn interpolate_boost_envelope_clamping() {
        let env = vec![(100.0, 5.0), (1000.0, 10.0)];
        assert_eq!(interpolate_boost_envelope(&env, 50.0), 5.0);
        assert_eq!(interpolate_boost_envelope(&env, 2000.0), 10.0);
    }

    #[test]
    fn interpolate_boost_envelope_interpolation() {
        let env = vec![(100.0, 0.0), (1000.0, 10.0)];
        let val = interpolate_boost_envelope(&env, 316.2277660168379);
        assert!((val - 5.0).abs() < 1e-9);
    }

    #[test]
    fn maybe_smooth_error_noop_when_disabled() {
        let freqs = Array1::from_vec(vec![100.0, 200.0]);
        let error = Array1::from_vec(vec![1.0, 2.0]);
        let out = maybe_smooth_error(&freqs, error.clone(), false, 1);
        assert_eq!(out.to_vec(), error.to_vec());
    }

    #[test]
    fn maybe_smooth_error_smooths_when_enabled() {
        let freqs = Array1::from_vec(vec![100.0, 150.0, 200.0]);
        let error = Array1::from_vec(vec![0.0, 10.0, 0.0]);
        let out = maybe_smooth_error(&freqs, error.clone(), true, 1);
        assert_eq!(out.len(), error.len());
        assert!(out[1] < error[1]);
        assert!(out[1] > 0.0);
    }
}
