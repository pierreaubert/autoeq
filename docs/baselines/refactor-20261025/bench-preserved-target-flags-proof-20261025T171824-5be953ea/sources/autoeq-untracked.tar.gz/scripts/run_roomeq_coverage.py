#!/usr/bin/env python3
"""Accumulate RoomEQ coverage once and retain the audited source inventory."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys

ROOM_PACKAGES = ('roomeq-model', 'roomeq-analysis', 'roomeq-quality', 'roomeq-engine',
                 'roomeq-export', 'roomeq-workflow', 'roomeq-dsp')
PACKAGES = (*ROOM_PACKAGES, 'autoeq-optim-types')
# Match complete source paths: relocated integration/QA fixtures never enter
# the denominator. Neutral config/loss originated outside the six RoomEQ crates.
SOURCE_PATTERN = (r'/crates/(?:' + '|'.join(ROOM_PACKAGES) + r')/src/.*\.rs$'
                  r'|/crates/autoeq-optim-types/src/(?:lib|evidence|reference_registry)\.rs$')


def included(filename: str) -> bool:
    return re.search(SOURCE_PATTERN, filename.replace('\\', '/')) is not None


def inventory(report: dict) -> dict:
    rows = []
    for entry in report['data'][0]['files']:
        filename = entry['filename']
        if not included(filename):
            raise ValueError(f'out-of-scope file in coverage report: {filename}')
        relative = 'crates/' + filename.replace('\\', '/').split('/crates/', 1)[1]
        if '/roomeq-dsp/' in relative:
            origin = 'roomeq-engine DSP realization / routing / channel FIR alignment'
        elif relative.endswith('/reference_registry.rs') and '/autoeq-optim-types/' in relative:
            origin = 'roomeq-model/src/reference_registry.rs'
        elif '/autoeq-optim-types/' in relative:
            origin = 'roomeq-model/src/report_contracts.rs (QAdjustment supplemental; previously optimizer-owned)'
        else:
            origin = relative
        rows.append({'path': relative, 'origin': origin, **entry['summary']['lines']})
    present = {row['path'].split('/')[1] for row in rows}
    missing = set(PACKAGES) - present
    if missing:
        raise ValueError(f'coverage has no source inventory for {sorted(missing)}')
    return {'scope': 'RoomEQ src files, including pre-existing embedded unit-test lines; external test and QA fixture files excluded',
            'supplemental_scope': 'QAdjustment in neutral evidence.rs originated in autoeq-optim, not the original six packages',
            'files': sorted(rows, key=lambda row: row['path'])}


def responsibility_lines(lcov: str, evidence_source: str) -> dict:
    """Remove only the explicitly mapped optimizer-origin Q helper lines."""
    marker = '/// One local-Q projection at a decoded filter center.'
    if evidence_source.count(marker) != 1:
        raise ValueError('cannot identify the supplemental QAdjustment source boundary')
    first_q_line = evidence_source[:evidence_source.index(marker)].count('\n') + 1
    files: dict[str, dict[int, bool]] = {}
    current = None
    for line in lcov.splitlines():
        if line.startswith('SF:'):
            current = line[3:].replace('\\', '/')
            if not included(current):
                raise ValueError(f'out-of-scope LCOV source: {current}')
            files.setdefault(current, {})
        elif line.startswith('DA:'):
            if current is None:
                raise ValueError('LCOV line data without source')
            number, hits, *_ = line[3:].split(',')
            number = int(number)
            files[current][number] = files[current].get(number, False) or int(hits) > 0
        elif line == 'end_of_record':
            current = None
    count = covered = supplemental_count = supplemental_covered = 0
    for filename, lines in files.items():
        for number, hit in lines.items():
            if filename.endswith('/autoeq-optim-types/src/evidence.rs') and number >= first_q_line:
                supplemental_count += 1
                supplemental_covered += hit
            else:
                count += 1
                covered += hit
    return {'count': count, 'covered': covered,
            'percent': 100 * covered / count if count else 0,
            'supplemental_count': supplemental_count,
            'supplemental_covered': supplemental_covered}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cargo', default='cargo')
    parser.add_argument('--resume-contributors', action='store_true', help='retain completed library profiles and run integration contributors')
    parser.add_argument('--report-only', action='store_true', help='audit existing release profiles without rerunning tests')
    parser.add_argument('--output', type=Path, default=Path('target/qa'))
    args = parser.parse_args()
    if not os.environ.get('AUTOEQ_REPORT_PRODUCER'):
        parser.error('run through scripts/run_with_report_producer.py --profile release')
    cargo = shlex.split(args.cargo)
    package_args = [arg for name in PACKAGES for arg in ('-p', name)]
    base = [*cargo, 'llvm-cov']
    run = lambda command: subprocess.run(command, check=True)
    if not args.report_only:
        # --no-report already retains profiles (and conflicts with --no-clean).
        # Follow cargo-llvm-cov's documented clean/accumulate/report sequence.
        if not args.resume_contributors:
            run([*base, 'clean', '--workspace'])
            run([*base, *package_args, '--lib', '--no-report', '--release'])
        contributors = [
            ('roomeq-workflow', ['dba_physical_outputs', 'joint_home_cinema', 'roomeq_pipeline_test', 'system_config_test']),
            ('roomeq-cli', ['roomeq_integration_test']),
            ('roomeq-qa', ['roomeq_generated_data_test']),
        ]
        for package, tests in contributors:
            run([*base, '-p', package,
                 *(arg for name in tests for arg in ('--test', name)), '--no-report', '--release'])
    args.output.mkdir(parents=True, exist_ok=True)
    root = Path(__file__).resolve().parents[1]
    outside = sorted(path.name for path in (root / 'crates').iterdir()
                     if path.is_dir() and path.name not in PACKAGES)
    ignore = (r'/(tests|benches|examples)/|/crates/(?:' + '|'.join(map(re.escape, outside))
              + r')/|/crates/autoeq-optim-types/src/(?:config|loss)\.rs$')
    # Dependencies outside selected workspace packages are ignored by
    # cargo-llvm-cov. inventory() rejects any unexpected remaining source.
    report_args = [*base, 'report', '--release', *package_args, '--ignore-filename-regex', ignore]
    report_path = args.output / 'roomeq-coverage.json'
    run([*report_args, '--json', '--summary-only', '--skip-functions', '--output-path', str(report_path)])
    data = json.loads(report_path.read_text())
    ownership = inventory(data)
    run([*report_args, '--lcov', '--output-path', str(args.output / 'roomeq-coverage.lcov')])
    responsibility = responsibility_lines((args.output / 'roomeq-coverage.lcov').read_text(),
        (root / 'crates/autoeq-optim-types/src/evidence.rs').read_text())
    for metric in ('count', 'covered'):
        if sum(row[metric] for row in ownership['files']) != responsibility[metric] + responsibility['supplemental_' + metric]:
            raise ValueError(f'LCOV and JSON line inventories disagree: {metric}')
    ownership['original_responsibility'] = responsibility
    (args.output / 'roomeq-coverage-ownership.json').write_text(json.dumps(ownership, indent=2) + '\n')
    print(f"Original RoomEQ responsibility: {responsibility['percent']:.2f}% (required 90%)", flush=True)
    subsystem = subprocess.run([sys.executable, str(root / 'scripts/check_roomeq_subsystem_coverage.py'), str(report_path)], check=False)
    aggregate = subprocess.run([*report_args, '--summary-only', '--fail-under-lines', '90'], check=False)
    return int(responsibility['percent'] < 90 or subsystem.returncode != 0 or aggregate.returncode != 0)



if __name__ == '__main__':
    raise SystemExit(main())
