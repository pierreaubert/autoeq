use roomeq_model::{FirConfig, MixedPhaseSerdeConfig, ProcessingMode};

/// Mode configuration for comparison tests
pub(super) struct ModeConfig {
    pub(super) name: &'static str,
    pub(super) processing_mode: ProcessingMode,
    pub(super) fir: Option<FirConfig>,
    pub(super) mixed_phase: Option<MixedPhaseSerdeConfig>,
}

pub(super) fn all_mode_configs() -> Vec<ModeConfig> {
    vec![
        ModeConfig {
            name: "iir",
            processing_mode: ProcessingMode::LowLatency,
            fir: None,
            mixed_phase: None,
        },
        ModeConfig {
            name: "fir",
            processing_mode: ProcessingMode::PhaseLinear,
            fir: Some(FirConfig {
                placement: Default::default(),
                taps: 4096,
                phase: "kirkeby".to_string(),
                correct_excess_phase: false,
                phase_smoothing: 0.167,
                pre_ringing: None,
                max_boost_db: None,
            }),
            mixed_phase: None,
        },
        ModeConfig {
            name: "hybrid",
            processing_mode: ProcessingMode::Hybrid,
            fir: Some(FirConfig {
                placement: Default::default(),
                taps: 4096,
                phase: "kirkeby".to_string(),
                correct_excess_phase: false,
                phase_smoothing: 0.167,
                pre_ringing: None,
                max_boost_db: None,
            }),
            mixed_phase: None,
        },
        ModeConfig {
            name: "mixed_phase",
            processing_mode: ProcessingMode::MixedPhase,
            fir: None,
            mixed_phase: Some(MixedPhaseSerdeConfig {
                max_fir_length_ms: 10.0,
                pre_ringing_threshold_db: -30.0,
                min_spatial_depth: 0.5,
                phase_smoothing_octaves: 0.167,
                assessment: Default::default(),
                max_correction_latency_ms: None,
            }),
        },
    ]
}
