use super::drivers_loss_data::DriversLossData;
use crate::Curve;

/// Crossover filter type for multi-driver optimization
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum CrossoverType {
    /// 2nd order Butterworth (12 dB/octave)
    Butterworth2,
    /// 4th order Butterworth (24 dB/octave)
    Butterworth4,
    /// 2nd order Linkwitz-Riley (12 dB/octave)
    LinkwitzRiley2,
    /// 4th order Linkwitz-Riley (24 dB/octave) — most common
    #[default]
    #[serde(alias = "LR24")]
    LinkwitzRiley4,
    /// 8th order Linkwitz-Riley (48 dB/octave)
    #[serde(alias = "LR48")]
    LinkwitzRiley8,
    /// Linear-phase FIR crossover with complementary low/high bands
    #[serde(alias = "LinearPhase")]
    LinearPhase,
    /// No crossover filter (for multi-sub optimization)
    None,
}

impl CrossoverType {
    /// Convert to a short plugin-compatible string.
    pub fn to_plugin_string(&self) -> &'static str {
        match self {
            CrossoverType::Butterworth2 => "Butterworth12",
            CrossoverType::Butterworth4 => "Butterworth24",
            CrossoverType::LinkwitzRiley2 => "LR12",
            CrossoverType::LinkwitzRiley4 => "LR24",
            CrossoverType::LinkwitzRiley8 => "LR48",
            CrossoverType::LinearPhase => "LinearPhase",
            CrossoverType::None => "None",
        }
    }

    /// Human-readable display name.
    pub fn display_name(&self) -> &'static str {
        match self {
            CrossoverType::Butterworth2 => "2nd order Butterworth",
            CrossoverType::Butterworth4 => "4th order Butterworth",
            CrossoverType::LinkwitzRiley2 => "2nd order Linkwitz-Riley",
            CrossoverType::LinkwitzRiley4 => "4th order Linkwitz-Riley",
            CrossoverType::LinkwitzRiley8 => "8th order Linkwitz-Riley",
            CrossoverType::LinearPhase => "Linear-phase FIR",
            CrossoverType::None => "No Crossover (Multi-Sub)",
        }
    }
}

impl std::str::FromStr for CrossoverType {
    type Err = String;

    fn from_str(s: &str) -> std::result::Result<Self, Self::Err> {
        match s.to_lowercase().as_str() {
            "butterworth2" | "bw2" | "butterworth12" | "bw12" => Ok(CrossoverType::Butterworth2),
            "butterworth4" | "bw4" | "butterworth24" | "bw24" => Ok(CrossoverType::Butterworth4),
            "lr2" | "lr12" | "linkwitzriley2" | "linkwitzriley12" => {
                Ok(CrossoverType::LinkwitzRiley2)
            }
            "lr4" | "lr24" | "linkwitzriley4" | "linkwitzriley24" => {
                Ok(CrossoverType::LinkwitzRiley4)
            }
            "lr8" | "lr48" | "linkwitzriley8" | "linkwitzriley48" => {
                Ok(CrossoverType::LinkwitzRiley8)
            }
            "linearphase" | "linear_phase" | "linear-phase" | "linearphasefir" | "fir"
            | "lpfir" => Ok(CrossoverType::LinearPhase),
            "none" => Ok(CrossoverType::None),
            _ => Err(format!("Unknown crossover type: {}", s)),
        }
    }
}

impl std::fmt::Display for CrossoverType {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.to_plugin_string())
    }
}

/// Interpolate and prepare driver curves on a common frequency grid
///
/// For every topology, including crossovers, the measured absolute
/// and relative SPL is preserved: each driver is only resampled to the common
/// grid. Normalizing each driver separately would erase the calibrated level
/// relationship between subs before interference is computed (a flat 80 dB
/// sub and a flat 70 dB sub must still sum to ~82.4 dB in phase, not 6 dB).
/// Flatness normalization belongs to the combined-sum loss, not the inputs.
pub(super) fn prepare_driver_curves(
    data: &DriversLossData,
    _crossover_freqs: &[f64],
) -> Vec<Curve> {
    data.drivers
        .iter()
        .map(|driver| {
            let curve = Curve {
                freq: driver.freq.clone(),
                spl: driver.spl.clone(),
                phase: driver.phase.clone(),
                ..Default::default()
            };
            // Crossover DSP acts on calibrated measurements. Independent passband
            // normalization changes relative source levels without exporting those
            // hidden trims, so the predicted response no longer matches playback.
            //
            // Edges hold instead of slope-extrapolating: a band-limited driver
            // (e.g. a subwoofer measured to 200 Hz on a grid spanning to 20 kHz)
            // must not invent hundreds of dB from one noisy edge bin. The held
            // level is then shaped by that driver's crossover low-pass, which
            // attenuates it to negligibility outside its passband.
            autoeq_core::interpolate_log_space_hold_edges(&data.freq_grid, &curve)
        })
        .collect()
}

/// Validate driver arguments (shared by combined and per-driver functions)
pub(super) fn validate_driver_args(
    data: &DriversLossData,
    gains: &[f64],
    crossover_freqs: &[f64],
    delays: Option<&[f64]>,
) {
    let n_drivers = data.drivers.len();
    assert_eq!(gains.len(), n_drivers);
    if !matches!(data.crossover_type, CrossoverType::None) {
        assert_eq!(crossover_freqs.len(), n_drivers - 1);
    }
    if let Some(d) = delays {
        assert_eq!(d.len(), n_drivers);
    }
}

#[cfg(test)]
mod tests {
    use super::CrossoverType;
    use std::str::FromStr;

    #[test]
    fn butterworth24_alias_parses_and_preserves_order() {
        let crossover = CrossoverType::from_str("BW24").expect("BW24 must be supported");
        assert_eq!(crossover, CrossoverType::Butterworth4);
        assert_eq!(crossover.to_plugin_string(), "Butterworth24");
    }

    #[test]
    fn crossover_preserves_calibrated_levels_and_explicit_gains() {
        use super::super::compute::compute_drivers_combined_response;
        use super::super::driver_measurement::DriverMeasurement;
        use super::super::drivers_loss_data::DriversLossData;
        let freq = ndarray::Array1::from_vec(vec![20.0, 80.0, 20_000.0]);
        let sub = DriverMeasurement {
            freq: freq.clone(),
            spl: ndarray::Array1::from_elem(3, 80.0),
            phase: None,
        };
        let main = DriverMeasurement {
            freq,
            spl: ndarray::Array1::from_elem(3, 70.0),
            phase: None,
        };
        let data = DriversLossData::new_ordered(vec![sub, main], CrossoverType::LinkwitzRiley4);
        for gain in [0.0, 6.0] {
            let combined = compute_drivers_combined_response(
                &data,
                &[gain, gain],
                &[80.0],
                Some(&[0.0, 0.0]),
                48_000.0,
            );
            assert!((combined[0] - 80.0 - gain).abs() < 0.1);
            assert!((combined[combined.len() - 1] - 70.0 - gain).abs() < 0.1);
        }
    }

    #[test]
    fn multisub_none_preserves_relative_calibrated_levels() {
        use super::super::compute::compute_drivers_combined_response;
        use super::super::driver_measurement::DriverMeasurement;
        use super::super::drivers_loss_data::DriversLossData;

        let freq = ndarray::Array1::from_vec(vec![20.0, 50.0, 100.0, 200.0]);
        let hot = DriverMeasurement {
            freq: freq.clone(),
            spl: ndarray::Array1::from_vec(vec![80.0; 4]),
            phase: None,
        };
        let quiet = DriverMeasurement {
            freq: freq.clone(),
            spl: ndarray::Array1::from_vec(vec![70.0; 4]),
            phase: None,
        };
        let data = DriversLossData::new_ordered(vec![hot, quiet], CrossoverType::None);
        let combined =
            compute_drivers_combined_response(&data, &[0.0, 0.0], &[], Some(&[0.0, 0.0]), 48_000.0);
        let expected = 20.0 * (10.0_f64.powf(80.0 / 20.0) + 10.0_f64.powf(70.0 / 20.0)).log10();
        for &level in combined.iter() {
            assert!(
                (level - expected).abs() < 0.35,
                "MSO sum must preserve calibrated levels: got {level:.3}, want {expected:.3}"
            );
        }
        // The old per-driver normalization collapsed both drivers to 0 dB and
        // summed to 6.02 dB; that must not regress.
        assert!(
            (expected - 6.0206).abs() > 10.0,
            "test premise broken: expected acoustic sum must differ from normalized sum"
        );
    }
}
