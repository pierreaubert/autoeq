use super::build::build_crossover_filters_for_driver;
use super::build::build_fir_crossover_coefficients_for_driver;
use super::crossover_type::prepare_driver_curves;
use super::crossover_type::validate_driver_args;
use super::drivers_loss_data::DriversLossData;
use super::misc::biquad_complex_response;
use super::misc::fir_complex_response;
use crate::Curve;
use ndarray::Array1;
use num_complex::Complex64;
use std::f64::consts::PI;

/// Compute the complex response of a single driver at all frequency points
fn compute_single_driver_complex(
    freq_grid: &Array1<f64>,
    curve: &Curve,
    gain: f64,
    delay_s: f64,
    filters: &[(f64, crate::iir::Biquad)],
    fir_filters: &[Vec<f64>],
    sample_rate: f64,
) -> Array1<Complex64> {
    let mag_factor = 10.0_f64.powf(gain / 20.0);
    let mut result = Array1::<Complex64>::zeros(freq_grid.len());

    for j in 0..freq_grid.len() {
        let f = freq_grid[j];
        let spl = curve.spl[j];

        let z_driver = if let Some(phase) = &curve.phase {
            let phi = phase[j].to_radians();
            let m = 10.0_f64.powf(spl / 20.0);
            Complex64::from_polar(m, phi)
        } else {
            let m = 10.0_f64.powf(spl / 20.0);
            Complex64::new(m, 0.0)
        };

        let phi_delay = -2.0 * PI * f * delay_s;
        let z_delay = Complex64::from_polar(1.0, phi_delay);

        let mut z_filters = Complex64::new(1.0, 0.0);
        for (_, biquad) in filters {
            z_filters *= biquad_complex_response(biquad, f);
        }
        for coeffs in fir_filters {
            z_filters *= fir_complex_response(coeffs, f, sample_rate);
        }

        result[j] = z_driver * mag_factor * z_filters * z_delay;
    }

    result
}

/// Compute the combined frequency response of multiple drivers with crossovers, gains, and delays
///
/// # Arguments
/// * `data` - DriversLossData containing driver measurements and crossover type
/// * `gains` - Gain in dB for each driver
/// * `crossover_freqs` - Crossover frequencies between successive driver pairs
/// * `delays` - Optional delay in ms for each driver
/// * `sample_rate` - Sample rate for filter design
///
/// # Returns
/// * Combined frequency response in dB on the common frequency grid
pub fn compute_drivers_combined_response(
    data: &DriversLossData,
    gains: &[f64],
    crossover_freqs: &[f64],
    delays: Option<&[f64]>,
    sample_rate: f64,
) -> Array1<f64> {
    validate_driver_args(data, gains, crossover_freqs, delays);

    let n_drivers = data.drivers.len();
    let driver_curves = prepare_driver_curves(data, crossover_freqs);

    // Sum complex responses
    let mut combined_complex = Array1::<Complex64>::zeros(data.freq_grid.len());

    for i in 0..n_drivers {
        let delay_s = delays.map(|d| d[i]).unwrap_or(0.0) / 1000.0;
        let filters = build_crossover_filters_for_driver(
            i,
            n_drivers,
            data.crossover_type,
            crossover_freqs,
            sample_rate,
        );
        let fir_filters = build_fir_crossover_coefficients_for_driver(
            i,
            n_drivers,
            data.crossover_type,
            crossover_freqs,
            sample_rate,
        );
        let driver_complex = compute_single_driver_complex(
            &data.freq_grid,
            &driver_curves[i],
            gains[i],
            delay_s,
            &filters,
            &fir_filters,
            sample_rate,
        );
        combined_complex += &driver_complex;
    }

    // Convert back to dB SPL
    combined_complex.mapv(|z| 20.0 * z.norm().max(1e-12).log10())
}

/// Compute the combined complex response of all drivers.
///
/// Same logic as `compute_drivers_combined_response()` but returns the raw
/// complex sum so that both magnitude (SPL) and phase can be extracted.
pub fn compute_drivers_combined_response_complex(
    data: &DriversLossData,
    gains: &[f64],
    crossover_freqs: &[f64],
    delays: Option<&[f64]>,
    sample_rate: f64,
) -> Array1<Complex64> {
    validate_driver_args(data, gains, crossover_freqs, delays);

    let n_drivers = data.drivers.len();
    let driver_curves = prepare_driver_curves(data, crossover_freqs);

    let mut combined_complex = Array1::<Complex64>::zeros(data.freq_grid.len());

    for i in 0..n_drivers {
        let delay_s = delays.map(|d| d[i]).unwrap_or(0.0) / 1000.0;
        let filters = build_crossover_filters_for_driver(
            i,
            n_drivers,
            data.crossover_type,
            crossover_freqs,
            sample_rate,
        );
        let fir_filters = build_fir_crossover_coefficients_for_driver(
            i,
            n_drivers,
            data.crossover_type,
            crossover_freqs,
            sample_rate,
        );
        let driver_complex = compute_single_driver_complex(
            &data.freq_grid,
            &driver_curves[i],
            gains[i],
            delay_s,
            &filters,
            &fir_filters,
            sample_rate,
        );
        combined_complex += &driver_complex;
    }

    combined_complex
}

/// Compute per-driver frequency responses with crossovers, gains, and delays applied
///
/// Same logic as `compute_drivers_combined_response()` but returns individual
/// driver responses instead of summing them into a single combined response.
///
/// # Arguments
/// * `data` - DriversLossData containing driver measurements and crossover type
/// * `gains` - Gain in dB for each driver
/// * `crossover_freqs` - Crossover frequencies between successive driver pairs
/// * `delays` - Optional delay in ms for each driver
/// * `sample_rate` - Sample rate for filter design
///
/// # Returns
/// * Vec of per-driver frequency responses in dB on the common frequency grid
pub fn compute_per_driver_responses(
    data: &DriversLossData,
    gains: &[f64],
    crossover_freqs: &[f64],
    delays: Option<&[f64]>,
    sample_rate: f64,
) -> Vec<Array1<f64>> {
    validate_driver_args(data, gains, crossover_freqs, delays);

    let n_drivers = data.drivers.len();
    let driver_curves = prepare_driver_curves(data, crossover_freqs);

    let mut results = Vec::with_capacity(n_drivers);
    for i in 0..n_drivers {
        let delay_s = delays.map(|d| d[i]).unwrap_or(0.0) / 1000.0;
        let filters = build_crossover_filters_for_driver(
            i,
            n_drivers,
            data.crossover_type,
            crossover_freqs,
            sample_rate,
        );
        let fir_filters = build_fir_crossover_coefficients_for_driver(
            i,
            n_drivers,
            data.crossover_type,
            crossover_freqs,
            sample_rate,
        );
        let driver_complex = compute_single_driver_complex(
            &data.freq_grid,
            &driver_curves[i],
            gains[i],
            delay_s,
            &filters,
            &fir_filters,
            sample_rate,
        );
        results.push(driver_complex.mapv(|z| 20.0 * z.norm().max(1e-12).log10()));
    }

    results
}
