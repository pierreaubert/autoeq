#[cfg(test)]
mod tests {
    use autoeq_core::MeasurementSource;
    use roomeq_model::{
        CrossoverConfig, OptimizerConfig, RoomConfig, SpeakerConfig, SubwooferStrategy,
        SystemConfig, SystemModel,
    };
    use roomeq_workflow::optimize_room;
    use std::collections::{HashMap, HashSet};

    // Helper to create a dummy curve in memory
    fn make_test_curve(base_level: f64) -> autoeq_core::Curve {
        let n = 100;
        let freq: Vec<f64> = (0..n)
            .map(|i| 20.0 * (1000.0f64).powf(i as f64 / n as f64))
            .collect();
        let spl: Vec<f64> = freq
            .iter()
            .map(|f| base_level + (f / 1000.0).ln() * 2.0)
            .collect();
        autoeq_core::Curve {
            freq: ndarray::Array1::from_vec(freq),
            spl: ndarray::Array1::from_vec(spl),
            // These are deterministic routing fixtures; declare their
            // relative phase explicitly so coherent 2.1 replay is assessed
            // rather than rejected for missing evidence.
            phase: Some(ndarray::Array1::zeros(n)),
            ..Default::default()
        }
    }

    fn routing_only_optimizer() -> OptimizerConfig {
        OptimizerConfig {
            num_filters: 0,
            max_iter: 1,
            population: 4,
            refine: false,
            decomposed_correction: None,
            ..Default::default()
        }
    }

    #[test]
    fn test_v2_1_system_config_stereo() {
        // Test basic mapping: Logical "L" -> "left_meas"
        let mut speakers = HashMap::new();
        speakers.insert(
            "left_meas".to_string(),
            SpeakerConfig::Single(MeasurementSource::InMemory(make_test_curve(80.0))),
        );
        speakers.insert(
            "right_meas".to_string(),
            SpeakerConfig::Single(MeasurementSource::InMemory(make_test_curve(80.0))),
        );

        let mut system_speakers = HashMap::new();
        system_speakers.insert("L".to_string(), "left_meas".to_string());
        system_speakers.insert("R".to_string(), "right_meas".to_string());

        let config = RoomConfig {
            version: "3.0.0".to_string(),
            system: Some(SystemConfig {
                model: SystemModel::Stereo,
                speakers: system_speakers,
                subwoofers: None,
                bass_management: None,
                supporting_source_outputs: None,
            }),
            speakers,
            crossovers: None,
            target_curve: None,
            optimizer: routing_only_optimizer(),
            provenance: Default::default(),
            recording_config: None,
            ctc: None,
            reporting: None,
            cea2034_cache: None,
            measured_impulse_responses: Default::default(),
        };

        let result = optimize_room(&config, 48000.0, None, None).expect("Optimization failed");

        let channel_names: HashSet<&str> = result.channels.keys().map(String::as_str).collect();
        assert_eq!(channel_names, HashSet::from(["L", "R"]));
    }

    #[test]
    fn test_v3_system_config_2_1() {
        // Stereo 2.1 has L/R programme inputs and one physical sub output.
        let mut speakers = HashMap::new();
        speakers.insert(
            "left_meas".to_string(),
            SpeakerConfig::Single(MeasurementSource::InMemory(make_test_curve(80.0))),
        );
        speakers.insert(
            "right_meas".to_string(),
            SpeakerConfig::Single(MeasurementSource::InMemory(make_test_curve(80.0))),
        );
        speakers.insert(
            "sub_meas".to_string(),
            SpeakerConfig::Single(MeasurementSource::InMemory(make_test_curve(90.0))),
        );

        let mut system_speakers = HashMap::new();
        system_speakers.insert("L".to_string(), "left_meas".to_string());
        system_speakers.insert("R".to_string(), "right_meas".to_string());

        let mut crossovers = HashMap::new();
        crossovers.insert(
            "sub_xo".to_string(),
            CrossoverConfig {
                crossover_type: "LR24".to_string(),
                frequency: Some(80.0),
                frequencies: None,
                frequency_range: None,
            },
        );

        let config = RoomConfig {
            version: "3.0.0".to_string(),
            system: Some(SystemConfig {
                model: SystemModel::Stereo, // 2.1 is stereo base
                speakers: system_speakers,
                subwoofers: Some(roomeq_model::SubwooferSystemConfig {
                    config: SubwooferStrategy::Single,
                    crossover: Some(roomeq_model::SubwooferCrossoverRef::PerSub(vec![
                        "sub_xo".to_string(),
                    ])),
                    routing: Default::default(),
                    outputs: vec![roomeq_model::SubwooferOutput {
                        id: "Sub1".to_string(),
                        speaker: "sub_meas".to_string(),
                    }],
                }),
                bass_management: None,
                supporting_source_outputs: None,
            }),
            speakers,
            crossovers: Some(crossovers),
            target_curve: None,
            optimizer: routing_only_optimizer(),
            provenance: Default::default(),
            recording_config: None,
            ctc: None,
            reporting: None,
            cea2034_cache: None,
            measured_impulse_responses: Default::default(),
        };

        let result = optimize_room(&config, 48000.0, None, None).expect("Optimization failed");

        let channel_names: HashSet<&str> = result.channels.keys().map(String::as_str).collect();
        assert_eq!(channel_names, HashSet::from(["L", "R", "Sub1"]));
    }

    #[test]
    fn optimize_room_rejects_invalid_sample_rates() {
        let config = RoomConfig {
            version: "3.0.0".to_string(),
            system: None,
            speakers: HashMap::from([(
                "left".to_string(),
                SpeakerConfig::Single(MeasurementSource::InMemory(make_test_curve(80.0))),
            )]),
            crossovers: None,
            target_curve: None,
            optimizer: routing_only_optimizer(),
            provenance: Default::default(),
            recording_config: None,
            ctc: None,
            reporting: None,
            cea2034_cache: None,
            measured_impulse_responses: Default::default(),
        };

        for sample_rate in [0.0, -48_000.0, f64::NAN, f64::INFINITY] {
            let error = optimize_room(&config, sample_rate, None, None)
                .expect_err("invalid sample rate must be rejected");
            let message = error.to_string();
            assert!(
                message.contains("sample rate") && message.contains("finite and positive"),
                "sample_rate={sample_rate}: unexpected error: {message}"
            );
        }
    }
}
