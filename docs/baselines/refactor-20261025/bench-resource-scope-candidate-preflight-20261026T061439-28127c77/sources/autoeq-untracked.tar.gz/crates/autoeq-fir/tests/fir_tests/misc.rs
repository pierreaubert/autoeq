use autoeq_core::Curve;
use std::path::PathBuf;

/// Load a test CSV file
pub(super) fn load_test_csv(filename: &str) -> Curve {
    let path = PathBuf::from(concat!(env!("CARGO_MANIFEST_DIR"), "/../.."))
        .join("tests/data/fir")
        .join(filename);

    autoeq_measurements::read::read_curve_from_csv(&path)
        .unwrap_or_else(|_| panic!("Failed to load {}", filename))
}

#[test]
fn test_load_flat_response_fixture() {
    let curve = load_test_csv("flat_response.csv");

    assert_eq!(curve.freq.len(), 10);
    assert_eq!(curve.spl.len(), 10);

    // All SPL values should be 85.0
    for &spl in curve.spl.iter() {
        assert!(
            (spl - 85.0).abs() < 0.01,
            "Flat response should have 85dB SPL, got {}",
            spl
        );
    }
}

#[test]
fn test_load_room_with_null_fixture() {
    let curve = load_test_csv("room_with_null.csv");

    assert!(curve.freq.len() > 5);

    // Find the null around 80Hz
    let null_idx = curve
        .freq
        .iter()
        .enumerate()
        .find(|(_, f)| (**f - 80.0).abs() < 1.0)
        .map(|(i, _)| i)
        .expect("Should have 80Hz point");

    let null_spl = curve.spl[null_idx];
    let surrounding_spl = (curve.spl[null_idx - 1] + curve.spl[null_idx + 1]) / 2.0;

    assert!(
        null_spl < surrounding_spl - 10.0,
        "Null should be >10dB below surrounding. Null: {}, Surrounding: {}",
        null_spl,
        surrounding_spl
    );
}

#[test]
fn test_load_peaked_response_fixture() {
    let curve = load_test_csv("peaked_response.csv");

    assert!(curve.freq.len() > 5);

    // Find the peak around 500Hz
    let peak_idx = curve
        .freq
        .iter()
        .enumerate()
        .find(|(_, f)| (**f - 500.0).abs() < 1.0)
        .map(|(i, _)| i)
        .expect("Should have 500Hz point");

    let peak_spl = curve.spl[peak_idx];

    // Peak should be at 95dB
    assert!(
        (peak_spl - 95.0).abs() < 0.1,
        "Peak should be at 95dB, got {}",
        peak_spl
    );

    // Surrounding points should be lower
    assert!(
        peak_spl > curve.spl[peak_idx - 1] + 3.0,
        "Peak should be higher than neighbors"
    );
    assert!(
        peak_spl > curve.spl[peak_idx + 1] + 3.0,
        "Peak should be higher than neighbors"
    );
}
