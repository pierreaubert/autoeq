"""Safety and measurement-contract tests for the isolated build harness."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch, Mock

sys.path.insert(0, str(Path(__file__).resolve().parent))
from bench_build import cargo_cmd, diagnostic_base_flags, summarize
from build_bench.probes import applied, literal_edit, select_edit
from build_bench.snapshots import Storage, copy_repository
from build_bench.execution import timed
from build_bench.plans import native_listing


class IsolationTests(unittest.TestCase):
    def test_dirty_snapshot_is_independent_and_preserves_deletions(self):
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            source = base / "source"
            source.mkdir()
            subprocess.run(["git", "init", "-q", str(source)], check=True)
            (source / "code.rs").write_text("fn value() -> usize { 2usize.max(1) }\n")
            (source / "deleted.rs").write_text("old")
            subprocess.run(["git", "add", "."], cwd=source, check=True)
            subprocess.run(["git", "-c", "user.name=Test", "-c", "user.email=test@example.test", "commit", "-qm", "fixture"], cwd=source, check=True)
            (source / "deleted.rs").unlink()
            (source / "input.json").write_text('{"new": true}')
            original = (source / "code.rs").read_bytes()
            copy = base / "copy"
            copy_repository(source, copy)
            self.assertFalse((copy / "deleted.rs").exists())
            self.assertEqual((copy / "input.json").read_bytes(), (source / "input.json").read_bytes())
            edit = literal_edit(copy / "code.rs", "private-edit")
            self.assertIsNotNone(edit)
            with self.assertRaisesRegex(RuntimeError, "build failed"):
                with applied(edit, copy):
                    self.assertNotEqual((copy / "code.rs").read_bytes(), original)
                    self.assertEqual((source / "code.rs").read_bytes(), original)
                    raise RuntimeError("build failed")
            self.assertEqual((copy / "code.rs").read_bytes(), original)

    def test_cleanup_refuses_unowned_paths_and_source_scratch(self):
        with tempfile.TemporaryDirectory() as temporary:
            parent = Path(temporary)
            source = parent / "source"
            source.mkdir()
            sentinel = source / "keep"
            sentinel.write_text("unchanged")
            with self.assertRaises(ValueError):
                Storage(source / "scratch", [source])
            storage = Storage(parent, [source])
            try:
                for path in (source, storage.root):
                    with self.assertRaises(ValueError):
                        storage.remove(path)
                link = storage.root / "escape"
                link.symlink_to(source, target_is_directory=True)
                with self.assertRaises(ValueError):
                    storage.remove(link)
            finally:
                storage.close()
            self.assertEqual(sentinel.read_text(), "unchanged")

    def test_probe_rejects_comment_and_outside_snapshot(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            path = root / "code.rs"
            path.write_text("// x.max(1)\nfn f() { let _ = 2usize.max(1); }\n")
            edit = literal_edit(path, "private-edit")
            self.assertEqual(edit.line, 2)
            self.assertIn(b"let autoeq_build_bench_value", edit.changed)
            with self.assertRaises(ValueError):
                with applied(edit, root / "elsewhere"):
                    self.fail("outside edit was allowed")

    def test_test_import_does_not_hide_production_code(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "lib.rs"
            path.write_text("#[cfg(test)] use example::Fixture;\nfn f() { let _ = 2usize.max(1); }\n#[cfg(test)] mod tests { fn f() { let _ = 2usize.max(2); } }\n")
            edit = literal_edit(path, "private-edit")
            self.assertEqual(edit.line, 2)
            self.assertIsNone(literal_edit(path, "test-edit"))

    def test_test_probe_requires_test_code(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "lib.rs"
            path.write_text("fn f() { assert_eq!(2, 2); }\n")
            self.assertIsNone(literal_edit(path, "test-edit"))
            path.write_text("#[cfg(test)] mod tests { #[test] fn f() { assert_eq!(2, 2); } }\n")
            self.assertIsNotNone(literal_edit(path, "test-edit"))


class MeasurementTests(unittest.TestCase):
    def test_scope_and_profile_are_explicit(self):
        command = cargo_cmd("affected-edit", ["autoeq-core", "autoeq-cli"], "qa", Path("/tmp/target"))
        self.assertIn("--all-features", command)
        self.assertIn("--locked", command)
        self.assertIn("--offline", command)
        self.assertEqual(command[command.index("--profile") + 1], "qa")
        self.assertEqual(command.count("-p"), 2)
        with self.assertRaises(ValueError):
            cargo_cmd("unknown", "core", "dev", Path("/tmp/target"))

    def test_execution_scope_matches_the_library_and_integration_inventory(self):
        command = native_listing("cargo", Path("/tmp/owned-target"), "qa")
        self.assertIn("--lib", command)
        self.assertIn("--tests", command)
        self.assertNotIn("--all-targets", command)
        self.assertEqual(command[command.index("--cargo-profile") + 1], "qa")

    def test_explicit_rustflags_precedence_is_preserved(self):
        flags = diagnostic_base_flags(Path('/source'), {'CARGO_ENCODED_RUSTFLAGS': '-C\x1ftarget-cpu=native',
                                                       'RUSTFLAGS': '-C opt-level=0'}, 'host')
        self.assertEqual(flags, ['-C', 'target-cpu=native'])
        self.assertEqual(diagnostic_base_flags(Path('/source'), {'RUSTFLAGS': '-C "link-arg=-L space path"'}, 'host'),
                         ['-C', 'link-arg=-L space path'])

    def test_cargo_target_flags_survive_instrumentation(self):
        flags = ['-C', 'link-arg=-mmacosx-version-min=15.0', '-C', 'link-arg=-framework', '-C', 'link-arg=Accelerate']
        query = Mock(cargo=Path('/nightly/cargo'))
        query.environment.return_value = {}
        response = Mock(returncode=0, stdout=json.dumps({'target': {'host': {'rustflags': flags}}}))
        with patch('bench_build.Toolchain.resolve', return_value=query), patch('bench_build.subprocess.run', return_value=response):
            self.assertEqual(diagnostic_base_flags(Path('/source'), {}, 'host'), flags)

    def test_unresolved_conditional_flags_fail_closed(self):
        query = Mock(cargo=Path('/nightly/cargo'))
        query.environment.return_value = {}
        response = Mock(returncode=0, stdout=json.dumps({'target': {'cfg(unix)': {'rustflags': ['-C', 'debuginfo=1']}}}))
        with patch('bench_build.Toolchain.resolve', return_value=query), patch('bench_build.subprocess.run', return_value=response):
            with self.assertRaisesRegex(RuntimeError, 'conditional target'):
                diagnostic_base_flags(Path('/source'), {}, 'host')

    def test_diagnostics_are_excluded_from_summary(self):
        normal = dict(case="core", scenario="clean-build", profile="dev", wall_seconds=1)
        diagnostic = dict(normal, wall_seconds=100, diagnostic=True)
        self.assertEqual(summarize([normal, diagnostic])[0]["median_wall_seconds"], 1)

    def test_failed_child_preserves_output_and_status(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            row = timed([sys.executable, "-c", "import sys; print('evidence'); sys.exit(7)"], root, dict(os.environ), root / "run")
            self.assertEqual(row["exit_code"], 7)
            self.assertEqual(Path(row["stdout"]).read_text().strip(), "evidence")
            self.assertGreater(row["wall_seconds"], 0)
            self.assertGreater(row["max_process_rss_bytes"], 0)


if __name__ == "__main__":
    unittest.main()
