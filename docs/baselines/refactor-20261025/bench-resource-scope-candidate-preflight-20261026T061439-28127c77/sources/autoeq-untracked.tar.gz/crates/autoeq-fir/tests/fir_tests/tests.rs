use super::compute::compute_fir_frequency_response;
use super::create::create_curve_with_null;
use super::create::create_flat_curve;
use super::create::create_test_curve;
use super::misc::load_test_csv;
use autoeq_core::Curve;
use autoeq_fir::{FirPhase, generate_fir_from_response};
use ndarray::Array1;

/// Compute RMS deviation between two curves (in dB).
fn compute_rms_deviation(curve1: &[f64], curve2: &[f64]) -> f64 {
    assert_eq!(curve1.len(), curve2.len());
    let sum_sq: f64 = curve1
        .iter()
        .zip(curve2.iter())
        .map(|(a, b)| (a - b).powi(2))
        .sum();
    (sum_sq / curve1.len() as f64).sqrt()
}

#[test]
fn test_fir_round_trip_flat_response() {
    // Generate FIR for flat response, apply it, verify result is still flat
    let sample_rate = 48000.0;
    let n_taps = 2048;

    // Target: flat at 0dB (unity gain)
    let target = create_flat_curve(20.0, 20000.0, 100, 0.0);

    let coeffs = generate_fir_from_response(&target, sample_rate, n_taps, FirPhase::Linear);

    // Compute frequency response of the FIR
    let test_freqs: Vec<f64> = (0..50)
        .map(|i| 20.0 * (20000.0 / 20.0_f64).powf(i as f64 / 49.0))
        .collect();

    let fir_response = compute_fir_frequency_response(&coeffs, sample_rate, &test_freqs);

    // The response should be approximately flat (near 0dB)
    // Allow some deviation due to windowing effects at band edges
    let mid_range_response: Vec<f64> = fir_response
        .iter()
        .zip(test_freqs.iter())
        .filter(|&(_, f)| *f >= 100.0 && *f <= 10000.0)
        .map(|(r, _)| *r)
        .collect();

    let mean_level: f64 = mid_range_response.iter().sum::<f64>() / mid_range_response.len() as f64;
    let max_deviation = mid_range_response
        .iter()
        .map(|&r| (r - mean_level).abs())
        .fold(0.0_f64, f64::max);

    assert!(
        max_deviation < 3.0,
        "Flat target should produce flat FIR response, max deviation = {:.2} dB",
        max_deviation
    );
}

#[test]
fn test_fir_round_trip_correction() {
    // Create a measurement with some deviation, generate correction, verify improvement
    let sample_rate = 48000.0;
    let n_taps = 4096;

    // Measurement with peaks and dips
    let measurement = create_test_curve(
        &[
            20.0, 50.0, 100.0, 200.0, 500.0, 1000.0, 2000.0, 5000.0, 10000.0, 20000.0,
        ],
        &[-3.0, 0.0, 3.0, 5.0, 2.0, 0.0, -2.0, -4.0, -6.0, -10.0],
    );

    // Target: flat at 0dB
    let target_spl = vec![0.0; measurement.spl.len()];

    // Correction curve = target - measurement (what we need to add)
    let correction_spl: Vec<f64> = target_spl
        .iter()
        .zip(measurement.spl.iter())
        .map(|(t, m)| t - m)
        .collect();

    let correction_curve = Curve {
        freq: measurement.freq.clone(),
        spl: Array1::from(correction_spl),
        phase: None,
        ..Default::default()
    };

    let coeffs =
        generate_fir_from_response(&correction_curve, sample_rate, n_taps, FirPhase::Linear);

    // Compute the FIR response
    let test_freqs: Vec<f64> = measurement.freq.to_vec();
    let fir_response = compute_fir_frequency_response(&coeffs, sample_rate, &test_freqs);

    // Apply correction: result = measurement + FIR response
    let corrected: Vec<f64> = measurement
        .spl
        .iter()
        .zip(fir_response.iter())
        .map(|(m, f)| m + f)
        .collect();

    // Focus on mid-band (100Hz - 5kHz) where FIR is most accurate
    let mid_indices: Vec<usize> = test_freqs
        .iter()
        .enumerate()
        .filter(|(_, f)| **f >= 100.0 && **f <= 5000.0)
        .map(|(i, _)| i)
        .collect();

    let original_mid: Vec<f64> = mid_indices.iter().map(|&i| measurement.spl[i]).collect();
    let corrected_mid: Vec<f64> = mid_indices.iter().map(|&i| corrected[i]).collect();
    let target_mid: Vec<f64> = vec![0.0; mid_indices.len()];

    let original_mid_dev = compute_rms_deviation(&original_mid, &target_mid);
    let corrected_mid_dev = compute_rms_deviation(&corrected_mid, &target_mid);

    // Corrected should be better than original in the mid-band
    // Allow for some tolerance since FIR windowing affects accuracy
    assert!(
        corrected_mid_dev <= original_mid_dev + 1.0, // Allow 1dB tolerance
        "FIR correction should improve or maintain response. Original dev: {:.2}dB, Corrected dev: {:.2}dB",
        original_mid_dev,
        corrected_mid_dev
    );
}

#[test]
fn test_fir_handles_room_null_gracefully() {
    // Test that FIR generation doesn't produce extreme coefficients for deep nulls
    let null_freq = 80.0;
    let null_depth = -30.0;

    let measurement = create_curve_with_null(null_freq, null_depth);

    // Target is flat at baseline level
    let baseline = 85.0;
    let target_spl: Vec<f64> = vec![baseline; measurement.spl.len()];

    // Compute correction curve
    let correction_spl: Vec<f64> = target_spl
        .iter()
        .zip(measurement.spl.iter())
        .map(|(t, m)| t - m)
        .collect();

    let correction_curve = Curve {
        freq: measurement.freq.clone(),
        spl: Array1::from(correction_spl),
        phase: None,
        ..Default::default()
    };

    let sample_rate = 48000.0;
    let n_taps = 4096;

    let coeffs =
        generate_fir_from_response(&correction_curve, sample_rate, n_taps, FirPhase::Linear);

    // FIR should be generated without panicking
    assert_eq!(coeffs.len(), n_taps);

    // Coefficients should be finite
    assert!(
        coeffs.iter().all(|&x| x.is_finite()),
        "All FIR coefficients should be finite"
    );

    // Compute the frequency response of the FIR filter
    let fir_response = compute_fir_frequency_response(&coeffs, sample_rate, &[null_freq]);

    // The boost at the null frequency might be large but should be finite
    let boost_at_null = fir_response[0];
    assert!(
        boost_at_null.is_finite(),
        "FIR response at null should be finite"
    );
}

#[test]
fn test_fir_from_fixture_data() {
    // Use fixture data to generate FIR and verify basic properties
    let measurement = load_test_csv("room_with_null.csv");
    let sample_rate = 48000.0;
    let n_taps = 4096;

    // Target: flat at 85dB (matching the baseline of the measurement)
    let target = create_flat_curve(20.0, 20000.0, 50, 85.0);

    // Compute correction curve
    let target_interp = autoeq_measurements::read::interpolate(&measurement.freq, &target);

    let correction_spl: Vec<f64> = target_interp
        .spl
        .iter()
        .zip(measurement.spl.iter())
        .map(|(t, m)| t - m)
        .collect();

    let correction_curve = Curve {
        freq: measurement.freq.clone(),
        spl: Array1::from(correction_spl),
        phase: None,
        ..Default::default()
    };

    let coeffs =
        generate_fir_from_response(&correction_curve, sample_rate, n_taps, FirPhase::Minimum);

    assert_eq!(coeffs.len(), n_taps);

    // FIR should have non-trivial coefficients
    let max_coeff = coeffs.iter().map(|x| x.abs()).fold(0.0_f64, f64::max);
    assert!(
        max_coeff > 0.001,
        "FIR should have significant coefficients"
    );

    // For minimum phase, energy should be concentrated toward the start
    // Note: The exact distribution depends on the target spectrum
    let first_half: f64 = coeffs[..n_taps / 2].iter().map(|x| x * x).sum();
    let total: f64 = coeffs.iter().map(|x| x * x).sum();

    // At least 30% of energy should be in first half for minimum phase
    // (this is more lenient as the actual distribution depends on the correction target)
    assert!(
        first_half / total > 0.3,
        "Minimum phase should have significant energy in first half, got {:.1}%",
        (first_half / total) * 100.0
    );
}

#[test]
fn test_fir_different_sample_rates() {
    // Test that FIR generation works with different sample rates
    let n_taps = 1024;

    let target = create_test_curve(
        &[20.0, 100.0, 1000.0, 10000.0, 20000.0],
        &[0.0, 2.0, 0.0, -2.0, -4.0],
    );

    for sample_rate in [44100.0, 48000.0, 96000.0] {
        let coeffs = generate_fir_from_response(&target, sample_rate, n_taps, FirPhase::Linear);

        assert_eq!(coeffs.len(), n_taps);
        assert!(
            coeffs.iter().any(|&x| x.abs() > 1e-10),
            "FIR at {}Hz should have non-zero coefficients",
            sample_rate
        );

        // Verify response at 1kHz (well within Nyquist for all rates)
        let response = compute_fir_frequency_response(&coeffs, sample_rate, &[1000.0]);
        assert!(
            response[0].is_finite(),
            "FIR response at 1kHz should be finite for {}Hz sample rate",
            sample_rate
        );
    }
}
