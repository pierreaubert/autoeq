use autoeq_core::Curve;
use autoeq_fir::{FirPhase, generate_fir_from_response, save_fir_to_wav};
use ndarray::Array1;
use tempfile::TempDir;

/// Create a synthetic frequency response curve
pub(super) fn create_test_curve(freqs: &[f64], spl_values: &[f64]) -> Curve {
    Curve {
        freq: Array1::from(freqs.to_vec()),
        spl: Array1::from(spl_values.to_vec()),
        phase: None,
        ..Default::default()
    }
}

/// Create a flat response at the given SPL level
pub(super) fn create_flat_curve(
    min_freq: f64,
    max_freq: f64,
    n_points: usize,
    spl_db: f64,
) -> Curve {
    let freqs: Vec<f64> = (0..n_points)
        .map(|i| {
            let t = i as f64 / (n_points - 1) as f64;
            min_freq * (max_freq / min_freq).powf(t)
        })
        .collect();
    let spl: Vec<f64> = vec![spl_db; n_points];
    create_test_curve(&freqs, &spl)
}

/// Create a response curve with a deep null at a specified frequency
pub(super) fn create_curve_with_null(null_freq: f64, null_depth_db: f64) -> Curve {
    // Create frequencies logarithmically spaced with extra points around the null
    let mut freqs = vec![20.0, 30.0, 40.0, 50.0, 60.0];

    // Add points around the null
    freqs.push(null_freq * 0.7);
    freqs.push(null_freq * 0.85);
    freqs.push(null_freq * 0.95);
    freqs.push(null_freq);
    freqs.push(null_freq * 1.05);
    freqs.push(null_freq * 1.15);
    freqs.push(null_freq * 1.3);

    // Continue with higher frequencies
    freqs.extend_from_slice(&[
        150.0, 200.0, 300.0, 500.0, 1000.0, 2000.0, 5000.0, 10000.0, 20000.0,
    ]);
    freqs.sort_by(f64::total_cmp);

    // Create SPL values with a null
    let baseline = 85.0;
    let spl: Vec<f64> = freqs
        .iter()
        .map(|&f| {
            // Create a narrow dip around the null frequency
            let distance = ((f / null_freq).ln()).abs();
            if distance < 0.2 {
                // Within the null region
                let depth = null_depth_db * (1.0 - distance / 0.2);
                baseline + depth
            } else {
                // Normal response with gentle rolloff
                baseline - (f.log10() - 2.5).abs() * 2.0
            }
        })
        .collect();

    create_test_curve(&freqs, &spl)
}

#[test]
fn test_fir_output_file_valid() {
    let temp_dir = TempDir::new().expect("Failed to create temp dir");
    let wav_path = temp_dir.path().join("test_output.wav");

    // Generate a realistic FIR filter
    let sample_rate = 48000.0;
    let n_taps = 1024;

    let target = create_test_curve(
        &[20.0, 100.0, 1000.0, 10000.0, 20000.0],
        &[0.0, 3.0, 0.0, -3.0, -6.0],
    );

    let coeffs = generate_fir_from_response(&target, sample_rate, n_taps, FirPhase::Linear);

    // Save to WAV
    let save_result = save_fir_to_wav(&coeffs, sample_rate as u32, &wav_path);
    assert!(save_result.is_ok(), "Should save FIR to WAV successfully");

    // Load and verify
    let reader = hound::WavReader::open(&wav_path).expect("Should open saved WAV");
    let spec = reader.spec();

    assert_eq!(spec.channels, 1, "FIR WAV should be mono");
    assert_eq!(spec.sample_rate, 48000, "Sample rate should match");
    assert_eq!(spec.bits_per_sample, 32, "Should be 32-bit");
    assert_eq!(
        reader.len() as usize,
        n_taps,
        "Sample count should match tap count"
    );

    // Read back samples and verify they're close to original
    let samples: Vec<f32> = reader
        .into_samples::<f32>()
        .map(|s| s.expect("Should read sample"))
        .collect();

    assert_eq!(samples.len(), coeffs.len());

    // Verify samples match (within f32 precision)
    for (i, (&original, &loaded)) in coeffs.iter().zip(samples.iter()).enumerate() {
        let diff = (original as f32 - loaded).abs();
        assert!(
            diff < 1e-6,
            "Sample {} mismatch: original={}, loaded={}",
            i,
            original,
            loaded
        );
    }
}

#[test]
fn test_linear_vs_minimum_phase_difference() {
    // Linear and minimum phase FIRs should produce different impulse responses
    let sample_rate = 48000.0;
    let n_taps = 2048;

    let target = create_test_curve(
        &[20.0, 100.0, 500.0, 1000.0, 5000.0, 20000.0],
        &[0.0, 3.0, 0.0, -2.0, -4.0, -8.0],
    );

    let linear_coeffs = generate_fir_from_response(&target, sample_rate, n_taps, FirPhase::Linear);
    let minimum_coeffs =
        generate_fir_from_response(&target, sample_rate, n_taps, FirPhase::Minimum);

    // Time-domain coefficients should be different
    let diff_sum: f64 = linear_coeffs
        .iter()
        .zip(minimum_coeffs.iter())
        .map(|(a, b)| (a - b).abs())
        .sum();

    assert!(
        diff_sum > 0.1,
        "Linear and minimum phase should have different coefficients"
    );

    // Linear phase should have peak near center
    let (linear_max_idx, _) = linear_coeffs
        .iter()
        .enumerate()
        .max_by(|a, b| a.1.abs().partial_cmp(&b.1.abs()).unwrap())
        .unwrap();

    let linear_center = n_taps / 2;
    let linear_distance = (linear_max_idx as isize - linear_center as isize).unsigned_abs();
    assert!(
        linear_distance < n_taps / 10,
        "Linear phase peak should be near center"
    );

    // Minimum phase should have more energy in the first half than linear phase
    // (comparing energy distributions rather than peak positions)
    let linear_first_half_energy: f64 = linear_coeffs[..n_taps / 2].iter().map(|x| x * x).sum();
    let linear_total_energy: f64 = linear_coeffs.iter().map(|x| x * x).sum();
    let linear_first_half_ratio = linear_first_half_energy / linear_total_energy;

    let minimum_first_half_energy: f64 = minimum_coeffs[..n_taps / 2].iter().map(|x| x * x).sum();
    let minimum_total_energy: f64 = minimum_coeffs.iter().map(|x| x * x).sum();
    let minimum_first_half_ratio = minimum_first_half_energy / minimum_total_energy;

    // Minimum phase should have higher first-half energy ratio than linear phase
    assert!(
        minimum_first_half_ratio > linear_first_half_ratio,
        "Minimum phase should have more energy in first half. Linear: {:.1}%, Minimum: {:.1}%",
        linear_first_half_ratio * 100.0,
        minimum_first_half_ratio * 100.0
    );
}

#[test]
fn test_fir_energy_conservation() {
    // Test that FIR filter has reasonable energy properties
    let sample_rate = 48000.0;
    let n_taps = 1024;

    // Flat 0dB target should produce filter with energy ≈ 1
    let target = create_flat_curve(20.0, 20000.0, 50, 0.0);
    let coeffs = generate_fir_from_response(&target, sample_rate, n_taps, FirPhase::Linear);

    // Total energy (sum of squares)
    let total_energy: f64 = coeffs.iter().map(|x| x * x).sum();

    // For a flat 0dB (unity gain) filter, energy should be around 1
    // Allow some tolerance due to windowing
    assert!(
        total_energy > 0.1 && total_energy < 10.0,
        "Unity gain FIR should have energy close to 1, got {}",
        total_energy
    );
}

#[test]
fn test_fir_different_tap_counts() {
    // Test that FIR generation works with various tap counts
    let sample_rate = 48000.0;

    let target = create_test_curve(
        &[20.0, 100.0, 1000.0, 10000.0, 20000.0],
        &[0.0, 2.0, 0.0, -2.0, -4.0],
    );

    for n_taps in [64, 256, 1024, 4096] {
        let coeffs = generate_fir_from_response(&target, sample_rate, n_taps, FirPhase::Linear);

        assert_eq!(
            coeffs.len(),
            n_taps,
            "Should produce requested number of taps: {}",
            n_taps
        );

        // Should produce valid coefficients
        assert!(
            coeffs.iter().all(|x| x.is_finite()),
            "All coefficients should be finite for {} taps",
            n_taps
        );
    }
}
