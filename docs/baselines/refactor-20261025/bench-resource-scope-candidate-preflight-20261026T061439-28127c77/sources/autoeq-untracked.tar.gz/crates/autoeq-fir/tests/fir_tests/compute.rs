use num_complex::Complex64;
use rustfft::FftPlanner;

/// Compute the frequency response of an FIR filter
pub(super) fn compute_fir_frequency_response(
    coeffs: &[f64],
    sample_rate: f64,
    frequencies: &[f64],
) -> Vec<f64> {
    let fft_size = coeffs.len().next_power_of_two() * 4;

    // Zero-pad the coefficients
    let mut padded: Vec<Complex64> = coeffs.iter().map(|&x| Complex64::new(x, 0.0)).collect();
    padded.resize(fft_size, Complex64::new(0.0, 0.0));

    // FFT
    let mut planner = FftPlanner::new();
    let fft = planner.plan_fft_forward(fft_size);
    fft.process(&mut padded);

    // Extract magnitude at requested frequencies
    let freq_step = sample_rate / fft_size as f64;

    frequencies
        .iter()
        .map(|&f| {
            let bin = (f / freq_step).round() as usize;
            let bin = bin.min(fft_size / 2);
            let mag = padded[bin].norm();
            20.0 * mag.max(1e-10).log10()
        })
        .collect()
}
